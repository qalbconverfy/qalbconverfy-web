from __future__ import annotations


def smoke_test() -> bool:
    return True