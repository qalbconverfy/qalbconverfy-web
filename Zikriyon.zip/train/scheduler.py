"""
zikriyon/train/scheduler.py
----------------------------
Learning rate scheduler with linear warmup + cosine decay.

Implements the schedule from "Attention Is All You Need" (extended with cosine decay):

    lr = d_model^(-0.5) * min(step^(-0.5), step * warmup_steps^(-1.5))

or equivalently a linear warmup followed by cosine annealing to a minimum LR.
"""

import math
import torch
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LambdaLR


class WarmupCosineScheduler(LambdaLR):
    """
    Linear warmup from 0 → base_lr over `warmup_steps`,
    then cosine decay from base_lr → min_lr over the remaining steps.

    Parameters
    ----------
    optimizer     : PyTorch optimizer
    warmup_steps  : number of steps for linear warmup
    total_steps   : total training steps
    min_lr_ratio  : final LR = base_lr * min_lr_ratio  (default 0.1)
    """

    def __init__(
        self,
        optimizer:    Optimizer,
        warmup_steps: int,
        total_steps:  int,
        min_lr_ratio: float = 0.1,
        last_epoch:   int   = -1,
    ):
        self.warmup_steps  = warmup_steps
        self.total_steps   = total_steps
        self.min_lr_ratio  = min_lr_ratio

        def lr_lambda(current_step: int) -> float:
            if current_step < warmup_steps:
                # Linear warmup
                return float(current_step) / float(max(1, warmup_steps))
            # Cosine decay
            progress = float(current_step - warmup_steps) / float(
                max(1, total_steps - warmup_steps)
            )
            cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
            return max(min_lr_ratio, cosine)

        super().__init__(optimizer, lr_lambda, last_epoch=last_epoch)


class WarmupConstantScheduler(LambdaLR):
    """
    Linear warmup then constant LR.
    Simple and often good enough for smaller models.
    """

    def __init__(self, optimizer: Optimizer, warmup_steps: int, last_epoch: int = -1):
        self.warmup_steps = warmup_steps

        def lr_lambda(current_step: int) -> float:
            if current_step < warmup_steps:
                return float(current_step) / float(max(1, warmup_steps))
            return 1.0

        super().__init__(optimizer, lr_lambda, last_epoch=last_epoch)
