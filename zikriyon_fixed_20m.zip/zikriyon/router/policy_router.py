from __future__ import annotations


def requires_approval(task: str) -> bool:
    text = task.lower()
    risky = [
        "delete",
        "remove",
        "wipe",
        "destroy",
        "format",
        "shutdown",
        "reboot",
        "transfer money",
        "send money",
        "purchase",
    ]
    return any(term in text for term in risky)