"""
zikriyon/tokenizer/tokenizer.py
--------------------------------
From-scratch BPE tokenizer for Zikriyon.
No pre-trained vocabulary — trained entirely on your own corpus.

Usage
-----
    from zikriyon.tokenizer import ZikriyonTokenizer

    tok = ZikriyonTokenizer(vocab_size=8000)
    tok.train(["path/to/corpus.txt", ...])
    tok.save("tokenizer/zikriyon.json")

    enc = tok.encode("Hello world")   # List[int]
    dec = tok.decode(enc)             # str
"""

import re
import json
import os
from collections import defaultdict
from pathlib import Path
from typing import List, Dict, Tuple, Optional


# ── Special tokens ────────────────────────────────────────────────────────────
PAD   = "<pad>"
BOS   = "<bos>"
EOS   = "<eos>"
UNK   = "<unk>"
MASK  = "<mask>"
SEP   = "<sep>"
SPECIAL_TOKENS = [PAD, BOS, EOS, UNK, MASK, SEP]


class ZikriyonTokenizer:
    """
    Byte-Pair Encoding tokenizer, trained from scratch on user-supplied text.

    The tokenizer stores:
        vocab      : token → id
        inv_vocab  : id → token
        merges     : ordered list of (A, B) merge rules
    """

    def __init__(self, vocab_size: int = 8000):
        self.vocab_size = vocab_size
        self.vocab: Dict[str, int] = {}
        self.inv_vocab: Dict[int, str] = {}
        self.merges: List[Tuple[str, str]] = []
        self._trained = False

        # special token ids (set after training / loading)
        self.pad_token_id  = 0
        self.bos_token_id  = 1
        self.eos_token_id  = 2
        self.unk_token_id  = 3
        self.mask_token_id = 4
        self.sep_token_id  = 5

    # ── Internal helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _pretokenize(text: str) -> List[str]:
        """Split text into words using a simple regex (space + punctuation aware)."""
        return re.findall(r"\S+|\n", text)

    @staticmethod
    def _word_to_chars(word: str) -> Tuple[str, ...]:
        """Convert word to character sequence with end-of-word marker."""
        chars = list(word)
        chars[-1] = chars[-1] + "</w>"
        return tuple(chars)

    @staticmethod
    def _get_pair_counts(vocab: Dict[Tuple, int]) -> Dict[Tuple, int]:
        pairs: Dict[Tuple, int] = defaultdict(int)
        for word, freq in vocab.items():
            symbols = list(word)
            for i in range(len(symbols) - 1):
                pairs[(symbols[i], symbols[i + 1])] += freq
        return pairs

    @staticmethod
    def _merge_vocab(
        pair: Tuple[str, str],
        vocab: Dict[Tuple, int],
    ) -> Dict[Tuple, int]:
        new_vocab: Dict[Tuple, int] = {}
        bigram = " ".join(pair)
        replacement = "".join(pair)
        for word, freq in vocab.items():
            word_str = " ".join(word)
            word_str = word_str.replace(bigram, replacement)
            new_word = tuple(word_str.split(" "))
            new_vocab[new_word] = freq
        return new_vocab

    # ── Training ─────────────────────────────────────────────────────────────

    def train(self, file_paths: List[str], verbose: bool = True) -> None:
        """
        Train BPE on text files.
        Each file is read line-by-line and pre-tokenized into words.
        """
        if verbose:
            print(f"[Tokenizer] Starting BPE training — target vocab size: {self.vocab_size}")

        # Build character-level word frequency table
        word_freq: Dict[Tuple, int] = defaultdict(int)
        total_tokens = 0
        for fpath in file_paths:
            with open(fpath, encoding="utf-8") as f:
                for line in f:
                    words = self._pretokenize(line.strip())
                    for w in words:
                        key = self._word_to_chars(w)
                        word_freq[key] += 1
                        total_tokens += 1

        if verbose:
            print(f"[Tokenizer] Corpus: {total_tokens:,} pre-tokens from {len(file_paths)} file(s)")

        # Collect initial character vocabulary
        char_vocab: set = set()
        for word in word_freq:
            for ch in word:
                char_vocab.add(ch)

        # Initialize vocab with special tokens first
        self.vocab = {}
        for tok in SPECIAL_TOKENS:
            self.vocab[tok] = len(self.vocab)
        for ch in sorted(char_vocab):
            if ch not in self.vocab:
                self.vocab[ch] = len(self.vocab)

        # BPE merge loop
        self.merges = []
        n_merges = self.vocab_size - len(self.vocab)

        for step in range(n_merges):
            pairs = self._get_pair_counts(word_freq)
            if not pairs:
                break
            best = max(pairs, key=pairs.get)
            word_freq = self._merge_vocab(best, word_freq)
            new_token = "".join(best)
            if new_token not in self.vocab:
                self.vocab[new_token] = len(self.vocab)
            self.merges.append(best)
            if verbose and (step + 1) % 500 == 0:
                print(f"  merge {step + 1}/{n_merges} — vocab size: {len(self.vocab)}")

        self.inv_vocab = {v: k for k, v in self.vocab.items()}
        self._set_special_ids()
        self._trained = True
        if verbose:
            print(f"[Tokenizer] Training complete — final vocab size: {len(self.vocab)}")

    def _set_special_ids(self):
        self.pad_token_id  = self.vocab.get(PAD,  0)
        self.bos_token_id  = self.vocab.get(BOS,  1)
        self.eos_token_id  = self.vocab.get(EOS,  2)
        self.unk_token_id  = self.vocab.get(UNK,  3)
        self.mask_token_id = self.vocab.get(MASK, 4)
        self.sep_token_id  = self.vocab.get(SEP,  5)

    # ── Encoding ─────────────────────────────────────────────────────────────

    def _apply_merges(self, word: Tuple[str, ...]) -> List[str]:
        """Apply learned merge rules to a character-split word."""
        symbols = list(word)
        merge_set = {pair: i for i, pair in enumerate(self.merges)}

        while True:
            pairs = [(symbols[i], symbols[i + 1]) for i in range(len(symbols) - 1)]
            eligible = [(merge_set[p], i, p) for i, p in enumerate(pairs) if p in merge_set]
            if not eligible:
                break
            _, pos, best = min(eligible)  # apply earliest merge first
            new_sym = "".join(best)
            symbols = symbols[:pos] + [new_sym] + symbols[pos + 2:]

        return symbols

    def encode(
        self,
        text: str,
        add_bos: bool = True,
        add_eos: bool = True,
        max_length: Optional[int] = None,
    ) -> List[int]:
        """Encode text → list of token ids."""
        assert self._trained, "Tokenizer not trained yet. Call .train() or .load() first."
        ids: List[int] = []
        if add_bos:
            ids.append(self.bos_token_id)

        words = self._pretokenize(text)
        for w in words:
            chars = self._word_to_chars(w)
            tokens = self._apply_merges(chars)
            for t in tokens:
                ids.append(self.vocab.get(t, self.unk_token_id))

        if add_eos:
            ids.append(self.eos_token_id)

        if max_length is not None:
            ids = ids[:max_length]

        return ids

    def encode_batch(
        self,
        texts: List[str],
        add_bos: bool = True,
        add_eos: bool = True,
        max_length: Optional[int] = None,
        pad: bool = True,
    ) -> Tuple[List[List[int]], List[List[int]]]:
        """
        Encode a batch of texts.
        Returns (input_ids, attention_masks).
        Pads to the longest sequence in the batch (or max_length).
        """
        encoded = [self.encode(t, add_bos, add_eos, max_length) for t in texts]
        max_len = max(len(e) for e in encoded)
        if max_length:
            max_len = min(max_len, max_length)

        input_ids, masks = [], []
        for seq in encoded:
            pad_len = max_len - len(seq)
            masks.append([1] * len(seq) + [0] * pad_len)
            input_ids.append(seq + [self.pad_token_id] * pad_len)

        return input_ids, masks

    def decode(self, ids: List[int], skip_special: bool = True) -> str:
        """Decode list of token ids → string."""
        tokens = []
        for i in ids:
            tok = self.inv_vocab.get(i, UNK)
            if skip_special and tok in SPECIAL_TOKENS:
                continue
            tokens.append(tok)
        text = "".join(tokens).replace("</w>", " ").strip()
        return text

    # ── Persistence ──────────────────────────────────────────────────────────

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "vocab_size": self.vocab_size,
            "vocab": self.vocab,
            "merges": self.merges,
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"[Tokenizer] saved → {path}")

    @classmethod
    def load(cls, path: str | Path) -> "ZikriyonTokenizer":
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        tok = cls(vocab_size=data["vocab_size"])
        tok.vocab = {k: int(v) for k, v in data["vocab"].items()}
        tok.inv_vocab = {int(v): k for k, v in data["vocab"].items()}
        tok.merges = [tuple(m) for m in data["merges"]]
        tok._set_special_ids()
        tok._trained = True
        print(f"[Tokenizer] loaded ← {path}  (vocab={len(tok.vocab)})")
        return tok

    # ── Properties ───────────────────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self.vocab)

    def __repr__(self) -> str:
        status = "trained" if self._trained else "untrained"
        return f"ZikriyonTokenizer(vocab_size={len(self.vocab)}, status={status})"