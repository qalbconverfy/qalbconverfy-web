from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import torch
from torch.utils.data import Dataset


@dataclass
class DatasetConfig:
    block_size: int = 512
    stride: int = 1
    train_split: float = 0.95
    min_tokens: int = 1024


class SequenceDataset(Dataset):
    def __init__(self, token_ids: Sequence[int], block_size: int, stride: int = 1):
        self.ids = torch.tensor(list(token_ids), dtype=torch.long)
        self.block_size = int(block_size)
        self.stride = int(stride)
        self.length = max(0, (len(self.ids) - self.block_size - 1) // self.stride + 1)

    def __len__(self):
        return self.length

    def __getitem__(self, idx):
        i = idx * self.stride
        x = self.ids[i : i + self.block_size]
        y = self.ids[i + 1 : i + self.block_size + 1]
        return x, y


def load_text_corpus(data_dir: str | Path) -> str:
    root = Path(data_dir)
    texts = []
    if root.exists():
        for p in sorted(root.rglob("*")):
            if p.is_file() and p.suffix.lower() in {".txt", ".md"}:
                texts.append(p.read_text(encoding="utf-8", errors="ignore"))
    return "\n\n".join(texts)


def create_datasets(tokenizer, text: str, cfg: DatasetConfig):
    ids = tokenizer.encode(text)
    if hasattr(ids, "tolist"):
        ids = ids.tolist()

    if len(ids) < cfg.min_tokens:
        raise ValueError(f"Need at least {cfg.min_tokens} tokens, got {len(ids)}")

    split_idx = max(cfg.block_size + 2, int(len(ids) * cfg.train_split))
    split_idx = min(split_idx, len(ids) - (cfg.block_size + 2))

    train_ids = ids[:split_idx]
    val_ids = ids[split_idx:]

    if len(val_ids) < cfg.block_size + 2:
        val_ids = ids[max(0, len(ids) - (cfg.block_size + 2)):]

    return (
        SequenceDataset(train_ids, cfg.block_size, cfg.stride),
        SequenceDataset(val_ids, cfg.block_size, cfg.stride),
    )