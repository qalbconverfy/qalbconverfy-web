from __future__ import annotations

import argparse
from pathlib import Path

from tokenizer.tokenizer import ByteBPETokenizer, TokenizerConfig


def load_texts(path: str) -> list[str]:
    p = Path(path)
    if p.is_dir():
        return [f.read_text(encoding="utf-8", errors="ignore") for f in sorted(p.rglob("*.txt"))]
    if p.is_file():
        return [p.read_text(encoding="utf-8", errors="ignore")]
    return []


def main():
    parser = argparse.ArgumentParser(description="Train Zikriyon tokenizer")
    parser.add_argument("--input", required=True, help="Text file or directory")
    parser.add_argument("--output", required=True, help="Tokenizer output directory")
    parser.add_argument("--vocab-size", type=int, default=32000)
    args = parser.parse_args()

    texts = load_texts(args.input)
    tok = ByteBPETokenizer(TokenizerConfig(vocab_size=args.vocab_size))
    tok.train(texts, target_vocab_size=args.vocab_size)
    tok.save(args.output)
    print(f"Saved tokenizer to {args.output}")


if __name__ == "__main__":
    main()