"""
zikriyon/inference/run.py
--------------------------
Command-line inference script for Zikriyon.

Usage
-----
    python -m zikriyon.inference.run \
        --checkpoint checkpoints/zikriyon_best.pt \
        --tokenizer  tokenizer/zikriyon_tokenizer.json \
        --prompt     "Summarize: The transformer architecture..."

    # Interactive mode
    python -m zikriyon.inference.run \
        --checkpoint checkpoints/zikriyon_best.pt \
        --tokenizer  tokenizer/zikriyon_tokenizer.json \
        --interactive
"""

import argparse
import torch

from ..config     import ZikriyonConfig
from ..model      import ZikriyonModel
from ..tokenizer  import ZikriyonTokenizer
from .generator   import ZikriyonGenerator


def main():
    parser = argparse.ArgumentParser(description="Zikriyon inference")
    parser.add_argument("--checkpoint",   required=True)
    parser.add_argument("--tokenizer",    required=True)
    parser.add_argument("--prompt",       type=str, default=None)
    parser.add_argument("--max_gen_len",  type=int,   default=None)
    parser.add_argument("--temperature",  type=float, default=None)
    parser.add_argument("--top_k",        type=int,   default=None)
    parser.add_argument("--top_p",        type=float, default=None)
    parser.add_argument("--interactive",  action="store_true")
    parser.add_argument("--device",       type=str, default="cpu")
    args = parser.parse_args()

    # Load
    tokenizer = ZikriyonTokenizer.load(args.tokenizer)
    model     = ZikriyonModel.load(args.checkpoint)
    model.cfg.device = args.device

    gen = ZikriyonGenerator(model, tokenizer, model.cfg, device=args.device)
    kwargs = {}
    if args.max_gen_len: kwargs["max_gen_len"] = args.max_gen_len
    if args.temperature:  kwargs["temperature"] = args.temperature
    if args.top_k:        kwargs["top_k"]       = args.top_k
    if args.top_p:        kwargs["top_p"]       = args.top_p

    if args.interactive:
        print("\n=== Zikriyon Interactive Mode ===  (type 'quit' to exit)\n")
        while True:
            prompt = input("You: ").strip()
            if prompt.lower() in ("quit", "exit", "q"):
                break
            if not prompt:
                continue
            response = gen.generate(prompt, **kwargs)
            print(f"Zikriyon: {response}\n")
    elif args.prompt:
        response = gen.generate(args.prompt, **kwargs)
        print(f"\nInput   : {args.prompt}")
        print(f"Output  : {response}")
    else:
        parser.error("Provide --prompt or --interactive")


if __name__ == "__main__":
    main()