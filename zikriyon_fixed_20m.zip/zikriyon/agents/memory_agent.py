from __future__ import annotations

from dataclasses import dataclass


@dataclass
class MemoryAgent:
    def run(self, request: str) -> str:
        return f"Memory workflow placeholder for: {request}"