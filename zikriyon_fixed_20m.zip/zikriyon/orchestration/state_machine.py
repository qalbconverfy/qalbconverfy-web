from __future__ import annotations

from dataclasses import dataclass


@dataclass
class StateMachine:
    state: str = "idle"

    def transition(self, new_state: str) -> None:
        self.state = new_state