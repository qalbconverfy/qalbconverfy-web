from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict
import yaml


@dataclass
class ZikriyonConfig:
    """Main configuration for Zikriyon."""
    project_name: str = "Zikriyon"
    environment: str = "development"

    data_dir: str = "./data"
    logs_dir: str = "./logs"
    checkpoints_dir: str = "./checkpoints"
    prompts_dir: str = "./prompts"

    device: str = "auto"
    seed: int = 42
    max_context_tokens: int = 4096
    enable_network: bool = True
    require_approval_for_high_risk: bool = True
    enable_image_generation: bool = False

    model_name: str = "zikriyon-core"
    vocab_size: int = 32000
    n_layers: int = 6
    n_heads: int = 8
    d_model: int = 512
    d_ff: int = 2048

    allow_command: bool = False
    allow_destructive: bool = False

    @classmethod
    def from_yaml(cls, path: str | Path = "configs/base.yaml") -> "ZikriyonConfig":
        path = Path(path)
        if not path.exists():
            return cls()

        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

        flat: Dict[str, Any] = {}
        for section in ["project", "paths", "runtime", "model", "safety"]:
            if section in data:
                flat.update(data[section])

        mapping = {
            "name": "project_name",
            "data_dir": "data_dir",
            "logs_dir": "logs_dir",
            "checkpoints_dir": "checkpoints_dir",
            "device": "device",
            "seed": "seed",
            "max_context_tokens": "max_context_tokens",
            "enable_network": "enable_network",
            "require_approval_for_high_risk": "require_approval_for_high_risk",
            "enable_image_generation": "enable_image_generation",
            "vocab_size": "vocab_size",
            "n_layers": "n_layers",
            "n_heads": "n_heads",
            "d_model": "d_model",
            "d_ff": "d_ff",
            "allow_command": "allow_command",
            "allow_destructive": "allow_destructive",
        }

        kwargs = {}
        for yaml_key, attr in mapping.items():
            if yaml_key in flat:
                kwargs[attr] = flat[yaml_key]

        return cls(**kwargs)


def load_config(path: str | Path = "configs/base.yaml") -> ZikriyonConfig:
    return ZikriyonConfig.from_yaml(path)