from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import yaml

from .dataset_builder import DatasetConfig, create_datasets, load_text_corpus
from .checkpointing import CheckpointManager
from .trainer import Trainer, TrainConfig

from zikriyon.core.model import ModelConfig, ZikriyonModel
from zikriyon.tokenizer.tokenizer import ByteBPETokenizer, TokenizerConfig


def load_train_config(path: str = "configs/train.yaml") -> TrainConfig:
    cfg = TrainConfig()
    p = Path(path)
    if not p.exists():
        print(f"[Warning] {p} not found. Using default train config.")
        return cfg
    data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    for key, value in data.items():
        if hasattr(cfg, key):
            setattr(cfg, key, value)
    if isinstance(cfg.betas, list):
        cfg.betas = tuple(cfg.betas)
    return cfg


def load_model_config(path: str = "configs/model.yaml") -> ModelConfig:
    p = Path(path)
    if not p.exists():
        print(f"[Warning] {p} not found. Using default model config.")
        return ModelConfig()
    data: dict[str, Any] = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    transformer = data.get("transformer", {}) or {}
    tokenizer = data.get("tokenizer", {}) or {}
    return ModelConfig(
        vocab_size=int(tokenizer.get("vocab_size", data.get("vocab_size", 32000))),
        n_layers=int(transformer.get("n_layers", data.get("n_layers", 6))),
        n_heads=int(transformer.get("n_heads", data.get("n_heads", 8))),
        d_model=int(transformer.get("d_model", data.get("d_model", 512))),
        d_ff=int(transformer.get("d_ff", data.get("d_ff", 2048))),
        dropout=float(transformer.get("dropout", data.get("dropout", 0.1))),
        max_seq_len=int(transformer.get("max_seq_len", data.get("max_seq_len", 4096))),
        rope_theta=float(transformer.get("rope_theta", data.get("rope_theta", 10000.0))),
        parameter_target=int(data.get("parameter_target", 20_000_000)),
    )


def count_parameters(model: ZikriyonModel) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def main() -> None:
    parser = argparse.ArgumentParser(description="Pretrain Zikriyon language model")
    parser.add_argument("--config", default="configs/train.yaml", help="Training YAML config")
    parser.add_argument("--model-config", default="configs/model.yaml", help="Model YAML config")
    parser.add_argument("--data-dir", default=None, help="Directory containing .txt/.md files")
    parser.add_argument("--resume", default="")
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--block-size", type=int, default=None)
    parser.add_argument("--overfit", action="store_true", help="Run a tiny laptop-safe overfit/smoke training")
    args = parser.parse_args()

    cfg = load_train_config(args.config)
    model_cfg = load_model_config(args.model_config)

    if args.data_dir:
        cfg.data_dir = args.data_dir
    if args.resume:
        cfg.resume = args.resume
    if args.max_steps is not None:
        cfg.max_steps = args.max_steps
    if args.batch_size is not None:
        cfg.batch_size = cfg.eval_batch_size = args.batch_size
    if args.block_size is not None:
        cfg.block_size = args.block_size

    if args.overfit:
        cfg.batch_size = cfg.eval_batch_size = 1
        cfg.block_size = min(cfg.block_size, 16)
        cfg.min_tokens = min(cfg.min_tokens, 128)
        cfg.max_steps = min(cfg.max_steps, 1)
        cfg.eval_every = 1
        cfg.save_every = 1
        cfg.grad_accum_steps = 1
        cfg.num_workers = 0
        cfg.max_eval_batches = 1
        cfg.amp = False
        model_cfg.vocab_size = min(model_cfg.vocab_size, 512)
        model_cfg.n_layers = min(model_cfg.n_layers, 1)
        model_cfg.n_heads = min(model_cfg.n_heads, 4)
        model_cfg.d_model = min(model_cfg.d_model, 64)
        model_cfg.d_ff = min(model_cfg.d_ff, 256)
        model_cfg.max_seq_len = min(model_cfg.max_seq_len, 512)

    print(f"[Train] max_steps={cfg.max_steps}, batch_size={cfg.batch_size}, block_size={cfg.block_size}")
    print(f"[Model] vocab={model_cfg.vocab_size}, layers={model_cfg.n_layers}, d_model={model_cfg.d_model}, heads={model_cfg.n_heads}")

    text = load_text_corpus(cfg.data_dir)
    if not text or len(text) < 500:
        print("[Warning] Using dummy data for testing")
        text = "The quick brown fox jumps over the lazy dog. Zikriyon learns tiny patterns. " * 400

    tokenizer = ByteBPETokenizer(TokenizerConfig(vocab_size=model_cfg.vocab_size))
    tokenizer.train([text], target_vocab_size=model_cfg.vocab_size)

    train_ds, val_ds = create_datasets(
        tokenizer,
        text,
        DatasetConfig(block_size=cfg.block_size, stride=cfg.stride, train_split=cfg.train_split, min_tokens=cfg.min_tokens),
    )

    model = ZikriyonModel(model_cfg)
    params = count_parameters(model)
    print(f"[Model] trainable_parameters={params:,}")
    if params > model_cfg.parameter_target:
        print(f"[Warning] parameter count exceeds target {model_cfg.parameter_target:,}")

    ckpt_manager = CheckpointManager(cfg.ckpt_dir)
    trainer = Trainer(model, tokenizer, train_ds, val_ds, cfg, ckpt_manager)
    print(trainer.train())


if __name__ == "__main__":
    main()
