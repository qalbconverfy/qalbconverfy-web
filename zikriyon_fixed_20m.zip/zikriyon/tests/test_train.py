from zikriyon.train.train import main

def test_train_imports():
    assert callable(main)