from __future__ import annotations


def safety_score(text: str) -> float:
    score = 1.0
    lowered = text.lower()
    for token in ["hack", "exploit", "steal", "malware", "phish", "bypass"]:
        if token in lowered:
            score -= 0.2
    return max(0.0, score)