from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List

from zikriyon.config import ZikriyonConfig


@dataclass
class SafetyPolicy:
    allow_read: bool = True
    allow_write: bool = True
    allow_network: bool = True
    allow_command: bool = False
    allow_destructive: bool = False
    allowed_tools: List[str] = field(default_factory=lambda: [
        "chat", "search", "fetch", "code", "pdf", "file", "command", "browser"
    ])
    confirm_required_terms: List[str] = field(default_factory=lambda: [
        "delete", "remove", "wipe", "destroy", "format", "shutdown", "reboot", "send money"
    ])

    @classmethod
    def from_config(cls, config: ZikriyonConfig) -> "SafetyPolicy":
        return cls(
            allow_command=config.allow_command,
            allow_destructive=config.allow_destructive,
            allow_network=config.enable_network,
        )

    def as_dict(self) -> Dict[str, object]:
        return {
            "allow_read": self.allow_read,
            "allow_write": self.allow_write,
            "allow_network": self.allow_network,
            "allow_command": self.allow_command,
            "allow_destructive": self.allow_destructive,
            "allowed_tools": list(self.allowed_tools),
            "confirm_required_terms": list(self.confirm_required_terms),
        }