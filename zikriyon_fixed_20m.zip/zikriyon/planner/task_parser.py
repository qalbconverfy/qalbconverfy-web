from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class ParsedTask:
    goal: str
    keywords: List[str]
    risk_level: str = "low"


def parse_task(task: str) -> ParsedTask:
    text = task.strip()
    lowered = text.lower()
    risk_terms = ["delete", "remove", "wipe", "destroy", "format", "transfer", "send money"]
    risk_level = "high" if any(term in lowered for term in risk_terms) else "low"
    keywords = [w for w in lowered.replace(",", " ").split() if len(w) > 2]
    return ParsedTask(goal=text, keywords=keywords[:12], risk_level=risk_level)