# Zikriyon Fix Report

## Verified commands

```bash
python -m compileall -q zikriyon
python -m zikriyon.train.train_tokenizer --input data/raw/tiny.txt --output tokenizer_test --vocab-size 300
python -m zikriyon.train.train --mode overfit --data-dir data/raw
python -m pytest zikriyon/tests/test_tokenizer.py zikriyon/tests/test_model.py zikriyon/tests/test_train.py -q
```

## Main fixes

- Fixed broken string literal in `zikriyon/safety/audit.py`.
- Fixed tokenizer regex pattern in `zikriyon/tokenizer/tokenizer.py`.
- Fixed wrong import in `zikriyon/train/train_tokenizer.py`.
- Fixed mutable dataclass defaults in `zikriyon/orchestration/workflow.py`.
- Removed eager imports from `zikriyon/train/__init__.py`.
- Added `--mode overfit` support to `zikriyon/train/train.py`.
- Made pretraining read `configs/model.yaml` instead of hardcoding model size.
- Added laptop-safe 20M max model config in `configs/model.yaml`.
- Made CPU training safer: AMP disables on CPU, pin_memory only enables on CUDA.
- Fixed checkpoint saving by using proper `CheckpointState` dataclass.
- Limited eval batches to avoid laptop training freeze.
- Fixed RoPE tensors to move to the same device/dtype as model tensors.

## Model size

`configs/model.yaml` is now about 16.8M trainable parameters, under the requested 20M max.

## Quick commands

Tokenizer:

```bash
python -m zikriyon.train.train_tokenizer --input data/raw --output tokenizer --vocab-size 8000
```

Smoke/overfit test:

```bash
python -m zikriyon.train.train --mode overfit --data-dir data/raw
```

Normal laptop training:

```bash
python -m zikriyon.train.train --stage 0 --data-dir data/raw --max-steps 100 --batch-size 1 --block-size 128
```
