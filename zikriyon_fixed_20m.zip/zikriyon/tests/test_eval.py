from zikriyon.eval.smoke_test import smoke_test

def test_smoke():
    assert smoke_test() is True