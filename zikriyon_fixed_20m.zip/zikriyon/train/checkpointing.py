from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import os
import shutil
import tempfile

import torch


@dataclass
class CheckpointState:
    step: int
    best_val_loss: float


class CheckpointManager:
    def __init__(self, directory: str | Path, filename: str = "last.pt", best_filename: str = "best.pt"):
        self.dir = Path(directory)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.filename = filename
        self.best_filename = best_filename

    def _atomic_save(self, obj, path: Path):
        fd, tmp = tempfile.mkstemp(dir=self.dir, suffix=".tmp")
        os.close(fd)
        try:
            torch.save(obj, tmp)
            shutil.move(tmp, path)
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)

    def save(self, model, optimizer, scheduler, scaler, state: CheckpointState):
        payload = {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict() if scheduler else None,
            "scaler": scaler.state_dict() if scaler else None,
            "state": asdict(state),
        }
        self._atomic_save(payload, self.dir / self.filename)

    def save_best(self, model, optimizer, scheduler, scaler, state: CheckpointState):
        payload = {
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict() if scheduler else None,
            "scaler": scaler.state_dict() if scaler else None,
            "state": asdict(state),
        }
        self._atomic_save(payload, self.dir / self.best_filename)

    def load(self, path: str | Path, model, optimizer=None, scheduler=None, scaler=None, map_location="cpu"):
        ckpt = torch.load(path, map_location=map_location)
        model.load_state_dict(ckpt["model"])
        if optimizer and ckpt.get("optimizer"):
            optimizer.load_state_dict(ckpt["optimizer"])
        if scheduler and ckpt.get("scheduler"):
            scheduler.load_state_dict(ckpt["scheduler"])
        if scaler and ckpt.get("scaler"):
            scaler.load_state_dict(ckpt["scaler"])
        return ckpt.get("state", {})