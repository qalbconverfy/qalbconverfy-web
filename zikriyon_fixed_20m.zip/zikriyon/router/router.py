from __future__ import annotations

from dataclasses import dataclass

from .model_router import select_model
from .policy_router import requires_approval
from .tool_selector import ToolSelection, select_tool


@dataclass
class RouteDecision:
    tool: str
    model: str
    approval_required: bool
    reason: str


class Router:
    def route(self, task: str) -> RouteDecision:
        selection: ToolSelection = select_tool(task)
        model = select_model(task)
        approval = requires_approval(task)
        return RouteDecision(
            tool=selection.tool_name,
            model=model,
            approval_required=approval,
            reason=selection.reason,
        )