from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn

from .decoder import Decoder
from .embeddings import TokenEmbedding
from .generation import greedy_generate


@dataclass
class ModelConfig:
    vocab_size: int = 32000
    n_layers: int = 6
    n_heads: int = 8
    d_model: int = 512
    d_ff: int = 2048
    dropout: float = 0.1
    max_seq_len: int = 4096
    rope_theta: float = 10000.0
    parameter_target: int = 20_000_000


class ZikriyonModel(nn.Module):
    def __init__(self, config: ModelConfig) -> None:
        super().__init__()
        self.config = config
        self.tok_emb = TokenEmbedding(config.vocab_size, config.d_model)
        self.decoder = Decoder(
            config.n_layers,
            config.d_model,
            config.n_heads,
            config.d_ff,
            config.dropout,
            config.max_seq_len,
            config.rope_theta,
        )
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)

    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        x = self.tok_emb(input_ids)
        x = self.decoder(x)
        return self.lm_head(x)

    @torch.no_grad()
    def generate(self, input_ids: torch.Tensor, max_new_tokens: int, eos_id: int | None = None) -> torch.Tensor:
        return greedy_generate(self, input_ids, max_new_tokens, eos_id)