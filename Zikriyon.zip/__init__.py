"""
Zikriyon — From-Scratch Encoder-Decoder Transformer
=====================================================
A fully original AI base model built in Python / PyTorch.

    from zikriyon.config    import ZikriyonConfig
    from zikriyon.model     import ZikriyonModel
    from zikriyon.tokenizer import ZikriyonTokenizer
    from zikriyon.inference import ZikriyonGenerator
"""

from .config    import ZikriyonConfig, tiny_config, small_config, base_config
from .model     import ZikriyonModel
from .tokenizer import ZikriyonTokenizer
from .inference import ZikriyonGenerator

__version__ = "0.1.0"
__author__  = "Zikriyon Project"

__all__ = [
    "ZikriyonConfig",
    "ZikriyonModel",
    "ZikriyonTokenizer",
    "ZikriyonGenerator",
    "tiny_config",
    "small_config",
    "base_config",
]