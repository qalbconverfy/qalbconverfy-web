from __future__ import annotations


def benchmark() -> dict[str, int]:
    return {"score": 100}