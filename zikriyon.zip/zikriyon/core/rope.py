from __future__ import annotations

import torch


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Rotate half the hidden dimensions of the input."""
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def precompute_rope_frequencies(
    seq_len: int, head_dim: int, theta: float = 10000.0
) -> tuple[torch.Tensor, torch.Tensor]:
    """
    Precompute the cos and sin frequencies for Rotary Position Embedding (RoPE).
    Returns tensors of shape (seq_len, head_dim) so they broadcast correctly.
    """
    inv_freq = 1.0 / (theta ** (torch.arange(0, head_dim, 2).float() / head_dim))
    positions = torch.arange(seq_len).float()
    freqs = torch.einsum("i,j->ij", positions, inv_freq)  # (seq_len, head_dim//2)

    # Repeat to full head_dim so shape matches with query/key tensors
    cos = freqs.cos().repeat_interleave(2, dim=-1)  # (seq_len, head_dim)
    sin = freqs.sin().repeat_interleave(2, dim=-1)  # (seq_len, head_dim)

    return cos, sin


def apply_rope(x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor) -> torch.Tensor:
    """
    Apply Rotary Position Embedding to query or key tensor.
    x: (batch_size, n_heads, seq_len, head_dim)
    cos, sin: (seq_len, head_dim)
    """
    # Slice to current sequence length and add batch + head dimensions
    cos = cos[: x.shape[2]].unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, head_dim)
    sin = sin[: x.shape[2]].unsqueeze(0).unsqueeze(0)

    return (x * cos) + (rotate_half(x) * sin)