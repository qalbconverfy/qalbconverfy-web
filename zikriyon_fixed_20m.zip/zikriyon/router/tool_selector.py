from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ToolSelection:
    tool_name: str
    reason: str


def select_tool(task: str) -> ToolSelection:
    text = task.lower()
    if any(k in text for k in ["search", "research", "web", "news"]):
        return ToolSelection("search", "Web research requested")
    if any(k in text for k in ["code", "debug", "python", "script"]):
        return ToolSelection("code", "Code execution requested")
    if "pdf" in text:
        return ToolSelection("pdf", "PDF generation requested")
    if any(k in text for k in ["file", "save", "write"]):
        return ToolSelection("file", "File operation requested")
    if any(k in text for k in ["run", "command", "shell"]):
        return ToolSelection("command", "Command execution requested")
    return ToolSelection("chat", "General conversation")