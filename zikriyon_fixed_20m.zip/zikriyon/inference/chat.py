from __future__ import annotations

import argparse

from .formatter import format_chat_response
from .runner import InferenceRunner


def chat_once(text: str) -> str:
    runner = InferenceRunner.build_default()
    return format_chat_response(runner.run(text))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Zikriyon chat")
    parser.add_argument("text", nargs="*", help="Input text")
    args = parser.parse_args()
    text = " ".join(args.text).strip() or "Hello Zikriyon"
    print(chat_once(text))


if __name__ == "__main__":
    main()