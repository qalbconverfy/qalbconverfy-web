from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ResearchAgent:
    def run(self, query: str) -> str:
        return f"Research workflow placeholder for: {query}"