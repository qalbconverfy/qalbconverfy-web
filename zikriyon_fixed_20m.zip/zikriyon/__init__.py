"""Zikriyon - AGI-style local assistant package."""

__version__ = "0.1.0"

# Optional: Expose key components at package level (recommended for convenience)
try:
    from .inference.chat import chat_once
    from .ui.app import main as launch_ui
except ImportError:
    # These imports are optional during early development
    pass

__all__ = [
    "__version__",
    "chat_once",
    "launch_ui",
]