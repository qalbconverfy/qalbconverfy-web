from __future__ import annotations

import argparse
import sys

from .pretrain import main as pretrain_main


def main() -> None:
    parser = argparse.ArgumentParser(description="Zikriyon training launcher")
    parser.add_argument("--stage", type=int, default=0, help="0=pretrain, 1+=future stages")
    parser.add_argument("--mode", choices=["normal", "overfit"], default="normal", help="normal or tiny overfit smoke run")
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--model-config", default="configs/model.yaml")
    parser.add_argument("--data-dir", default=None)
    parser.add_argument("--resume", default="")
    parser.add_argument("--max-steps", type=int, default=None)
    parser.add_argument("--batch-size", type=int, default=None)
    parser.add_argument("--block-size", type=int, default=None)
    args = parser.parse_args()

    forwarded = [
        "--config", args.config,
        "--model-config", args.model_config,
    ]
    if args.data_dir:
        forwarded += ["--data-dir", args.data_dir]
    if args.resume:
        forwarded += ["--resume", args.resume]
    if args.max_steps is not None:
        forwarded += ["--max-steps", str(args.max_steps)]
    if args.batch_size is not None:
        forwarded += ["--batch-size", str(args.batch_size)]
    if args.block_size is not None:
        forwarded += ["--block-size", str(args.block_size)]
    if args.mode == "overfit":
        forwarded.append("--overfit")

    if args.stage != 0:
        print(f"[Info] stage {args.stage} is not implemented yet. Running pretrain pipeline.")

    old_argv = sys.argv
    try:
        sys.argv = [old_argv[0], *forwarded]
        pretrain_main()
    finally:
        sys.argv = old_argv


if __name__ == "__main__":
    main()
