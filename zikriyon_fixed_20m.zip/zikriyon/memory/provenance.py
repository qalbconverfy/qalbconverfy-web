from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass
class Provenance:
    source: str
    source_type: str
    created_at: str
    verified: bool = False

    @classmethod
    def new(cls, source: str, source_type: str, verified: bool = False) -> "Provenance":
        return cls(
            source=source,
            source_type=source_type,
            created_at=datetime.now(timezone.utc).isoformat(),
            verified=verified,
        )