from __future__ import annotations

def build_title() -> str:
    return "Zikriyon"