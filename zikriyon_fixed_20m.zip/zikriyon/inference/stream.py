from __future__ import annotations

from typing import Iterator


def stream_text(text: str) -> Iterator[str]:
    for token in text.split():
        yield token + " "