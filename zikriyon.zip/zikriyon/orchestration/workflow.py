from __future__ import annotations

from dataclasses import dataclass

from .lifecycle import Lifecycle
from .state_machine import StateMachine


@dataclass
class WorkflowEngine:
    lifecycle: Lifecycle = Lifecycle()
    state_machine: StateMachine = StateMachine()

    def start(self) -> None:
        self.lifecycle.start()
        self.state_machine.transition("running")

    def stop(self) -> None:
        self.lifecycle.stop()
        self.state_machine.transition("stopped")