from __future__ import annotations


def format_chat_response(text: str) -> str:
    return text.strip()