from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .task_parser import ParsedTask


@dataclass
class Step:
    title: str
    action: str
    tool_hint: str | None = None


def build_steps(parsed: ParsedTask) -> List[Step]:
    steps: List[Step] = []
    if parsed.risk_level == "high":
        steps.append(Step(title="Safety review", action="check_policy", tool_hint="safety"))
    if "search" in parsed.keywords or "research" in parsed.keywords:
        steps.append(Step(title="Collect sources", action="web_search", tool_hint="search"))
    if "code" in parsed.keywords or "debug" in parsed.keywords:
        steps.append(Step(title="Inspect code", action="run_code", tool_hint="code"))
    if "pdf" in parsed.keywords or "document" in parsed.keywords:
        steps.append(Step(title="Generate document", action="make_pdf", tool_hint="pdf"))
    if not steps:
        steps.append(Step(title="Solve request", action="direct_answer", tool_hint=None))
    return steps