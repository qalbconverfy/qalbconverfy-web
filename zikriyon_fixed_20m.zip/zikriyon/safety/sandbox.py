from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SandboxConfig:
    read_only: bool = False
    network_enabled: bool = True
    time_limit_seconds: int = 30
    memory_limit_mb: int = 512


class Sandbox:
    def __init__(self, config: SandboxConfig | None = None) -> None:
        self.config = config or SandboxConfig()

    def describe(self) -> dict:
        return {
            "read_only": self.config.read_only,
            "network_enabled": self.config.network_enabled,
            "time_limit_seconds": self.config.time_limit_seconds,
            "memory_limit_mb": self.config.memory_limit_mb,
        }