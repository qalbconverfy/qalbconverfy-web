from __future__ import annotations


def score_response(text: str) -> float:
    score = 0.5
    if len(text.strip()) > 20:
        score += 0.2
    if any(p in text for p in [".", "!", "?"]):
        score += 0.1
    if len(text.split()) > 5:
        score += 0.1
    return min(score, 1.0)