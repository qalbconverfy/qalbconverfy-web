from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class LongTermMemory:
    store: Dict[str, Any] = field(default_factory=dict)

    def set(self, key: str, value: Any) -> None:
        self.store[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self.store.get(key, default)

    def delete(self, key: str) -> None:
        if key in self.store:
            del self.store[key]

    def keys(self) -> List[str]:
        return list(self.store.keys())