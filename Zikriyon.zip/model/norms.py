"""
zikriyon/model/norms.py
------------------------
Normalization layers used throughout Zikriyon.

Provides:
    RMSNorm   — Root Mean Square Layer Normalization (no bias, no mean shift)
    LayerNorm — thin wrapper around nn.LayerNorm for drop-in compatibility
"""

import torch
import torch.nn as nn


class RMSNorm(nn.Module):
    """
    Root Mean Square Layer Normalization.

    Faster than LayerNorm (no mean subtraction), used in LLaMA / Mistral style models.

    y = x / RMS(x) * weight
    where RMS(x) = sqrt(mean(x^2) + eps)

    Shape: (batch, seq_len, d_model) → same
    """

    def __init__(self, d_model: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(d_model))
        self.eps    = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (..., d_model)
        rms = x.pow(2).mean(-1, keepdim=True).add(self.eps).rsqrt()
        return x * rms * self.weight


class LayerNorm(nn.Module):
    """
    Standard Layer Normalization.

    A thin wrapper around nn.LayerNorm so both norms share the same interface.
    Pre-norm style: norm is applied before the sub-layer (not after).
    """

    def __init__(self, d_model: int, eps: float = 1e-6):
        super().__init__()
        self.norm = nn.LayerNorm(d_model, eps=eps)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.norm(x)


def get_norm(norm_type: str, d_model: int) -> nn.Module:
    """Factory: return the requested norm layer."""
    if norm_type == "rmsnorm":
        return RMSNorm(d_model)
    elif norm_type == "layernorm":
        return LayerNorm(d_model)
    else:
        raise ValueError(f"Unknown norm_type: {norm_type}")
