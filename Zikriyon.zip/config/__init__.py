from .config import ZikriyonConfig, tiny_config, small_config, base_config

__all__ = ["ZikriyonConfig", "tiny_config", "small_config", "base_config"]