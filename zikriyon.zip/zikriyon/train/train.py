from __future__ import annotations

import argparse
from .pretrain import main as pretrain_main


def main():
    parser = argparse.ArgumentParser(description="Zikriyon Training")
    parser.add_argument("--stage", type=int, default=0, help="0=pretrain, 1=finetune")
    args = parser.parse_args()

    if args.stage == 0:
        print("Starting Pretraining...")
        pretrain_main()
    else:
        print("Finetune stage not implemented yet. Running pretrain instead.")
        pretrain_main()


if __name__ == "__main__":
    main()