from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import time
import os

import torch
from torch.utils.data import DataLoader

from zikriyon.core.losses import causal_lm_loss
from zikriyon.train.checkpointing import CheckpointState

try:
    import wandb
    WANDB_AVAILABLE = True
except ImportError:
    WANDB_AVAILABLE = False


@dataclass
class TrainConfig:
    data_dir: str = "./data/raw"
    output_dir: str = "./output"
    ckpt_dir: str = "./checkpoints"
    log_dir: str = "./logs"

    batch_size: int = 16
    eval_batch_size: int = 16
    block_size: int = 512
    stride: int = 1
    train_split: float = 0.95
    min_tokens: int = 1024

    lr: float = 3e-4
    weight_decay: float = 0.1
    betas: tuple = (0.9, 0.95)
    grad_clip_norm: float = 1.0
    grad_accum_steps: int = 4
    max_steps: int = 5000
    eval_every: int = 200
    save_every: int = 200
    warmup_steps: int = 200

    num_workers: int = 4
    amp: bool = True
    compile: bool = False
    seed: int = 42
    resume: str = ""
    device: str = "auto"
    log_to_file: bool = True
    max_eval_batches: int = 20

    # W&B
    use_wandb: bool = False
    wandb_project: str = "zikriyon-training"
    wandb_run_name: str = ""


class Trainer:
    def __init__(self, model, tokenizer, train_ds, val_ds, cfg: TrainConfig, checkpoint_manager):
        self.model = model
        self.tokenizer = tokenizer
        self.train_ds = train_ds
        self.val_ds = val_ds
        self.cfg = cfg
        self.checkpoint_manager = checkpoint_manager

        
        if cfg.device and cfg.device != "auto":
            self.device = torch.device(cfg.device)
        else:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        if self.device.type != "cuda":
            self.cfg.amp = False
        torch.manual_seed(cfg.seed)

        if cfg.compile:
            try:
                self.model = torch.compile(self.model)
            except Exception:
                pass

        self.model.to(self.device)

        self.optimizer = torch.optim.AdamW(
            self.model.parameters(),
            lr=cfg.lr,
            betas=cfg.betas,
            weight_decay=cfg.weight_decay
        )

        self.scheduler = torch.optim.lr_scheduler.LambdaLR(
            self.optimizer,
            lambda step: min(1.0, float(step + 1) / max(1, cfg.warmup_steps))
        )

        self.scaler = torch.amp.GradScaler("cuda", enabled=(cfg.amp and self.device.type == "cuda"))

        self.train_loader = DataLoader(
            train_ds, batch_size=cfg.batch_size, shuffle=True,
            num_workers=cfg.num_workers, pin_memory=(self.device.type == "cuda"), drop_last=True
        )
        self.val_loader = DataLoader(
            val_ds, batch_size=cfg.eval_batch_size, shuffle=False,
            num_workers=cfg.num_workers, pin_memory=(self.device.type == "cuda")
        )

        Path(cfg.ckpt_dir).mkdir(parents=True, exist_ok=True)
        Path(cfg.log_dir).mkdir(parents=True, exist_ok=True)

        self.global_step = 0
        self.best_val_loss = float("inf")
        self._train_iter = iter(self.train_loader)

        # === W&B Initialization ===
        self.use_wandb = cfg.use_wandb and WANDB_AVAILABLE
        if self.use_wandb:
            wandb.init(
                project=cfg.wandb_project,
                name=cfg.wandb_run_name or None,
                config=vars(cfg)
            )
            wandb.watch(self.model, log="all", log_freq=100)

    def evaluate(self):
        self.model.eval()
        total_loss = 0
        count = 0
        with torch.no_grad():
            for batch_idx, (xb, yb) in enumerate(self.val_loader):
                xb, yb = xb.to(self.device), yb.to(self.device)
                with torch.amp.autocast(device_type=self.device.type, enabled=(self.cfg.amp and self.device.type == "cuda")):
                    logits = self.model(xb)
                    loss = causal_lm_loss(logits, yb)
                total_loss += loss.item()
                count += 1
                if self.cfg.max_eval_batches and count >= self.cfg.max_eval_batches:
                    break
        self.model.train()
        return total_loss / max(1, count)

    def train(self):
        self.model.train()
        start_time = time.time()

        for step in range(self.global_step, self.cfg.max_steps):
            self.global_step = step
            self.optimizer.zero_grad(set_to_none=True)
            accum_loss = 0.0

            for _ in range(self.cfg.grad_accum_steps):
                try:
                    xb, yb = next(self._train_iter)
                except StopIteration:
                    self._train_iter = iter(self.train_loader)
                    xb, yb = next(self._train_iter)

                xb, yb = xb.to(self.device), yb.to(self.device)

                with torch.amp.autocast(device_type=self.device.type, enabled=(self.cfg.amp and self.device.type == "cuda")):
                    logits = self.model(xb)
                    loss = causal_lm_loss(logits, yb) / self.cfg.grad_accum_steps

                self.scaler.scale(loss).backward()
                accum_loss += loss.item()

            if self.cfg.grad_clip_norm > 0:
                self.scaler.unscale_(self.optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip_norm)

            self.scaler.step(self.optimizer)
            self.scaler.update()
            self.scheduler.step()

            if step % self.cfg.eval_every == 0 or step == self.cfg.max_steps - 1:
                val_loss = self.evaluate()

                if val_loss < self.best_val_loss:
                    self.best_val_loss = val_loss
                    self._save(val_loss, step, is_best=True)
                else:
                    self._save(val_loss, step, is_best=False)

                metrics = {
                    "step": step,
                    "train_loss": round(accum_loss, 4),
                    "val_loss": round(val_loss, 4),
                    "best_val_loss": round(self.best_val_loss, 4),
                    "lr": round(self.optimizer.param_groups[0]["lr"], 6),
                    "time_min": round((time.time() - start_time) / 60, 2)
                }

                self._log(metrics)

                if self.use_wandb:
                    wandb.log(metrics)

            elif step % self.cfg.save_every == 0:
                self._save(float("inf"), step, is_best=False)

        if self.use_wandb:
            wandb.finish()

        return {"best_val_loss": self.best_val_loss, "steps": self.global_step}

    def _save(self, val_loss, step, is_best=False):
        state = CheckpointState(step=step, best_val_loss=self.best_val_loss)
        if is_best:
            self.checkpoint_manager.save_best(self.model, self.optimizer, self.scheduler, self.scaler, state)
        else:
            self.checkpoint_manager.save(self.model, self.optimizer, self.scheduler, self.scaler, state)

    def _log(self, data: dict):
        print(data)
        if self.cfg.log_to_file:
            log_path = Path(self.cfg.log_dir) / "train.jsonl"
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(data, ensure_ascii=False) + "\n")