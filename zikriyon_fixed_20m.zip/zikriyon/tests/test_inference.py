from zikriyon.inference.chat import chat_once

def test_chat_once():
    out = chat_once("hello")
    assert isinstance(out, str)