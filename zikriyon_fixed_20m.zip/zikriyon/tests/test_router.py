from zikriyon.router.router import Router

def test_router_selects_tool():
    decision = Router().route("search the web")
    assert decision.tool == "search"