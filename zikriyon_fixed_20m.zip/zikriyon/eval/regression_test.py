from __future__ import annotations


def regression_test() -> bool:
    return True