from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PdfAgent:
    def run(self, request: str) -> str:
        return f"PDF workflow placeholder for: {request}"