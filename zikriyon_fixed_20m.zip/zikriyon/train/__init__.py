"""Training package for Zikriyon."""

__all__: list[str] = []
