from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .goal_manager import GoalManager
from .step_builder import Step, build_steps
from .task_parser import ParsedTask, parse_task


@dataclass
class Plan:
    goal: str
    parsed: ParsedTask
    steps: List[Step] = field(default_factory=list)


class Planner:
    def __init__(self) -> None:
        self.goal_manager = GoalManager()

    def plan(self, task: str) -> Plan:
        parsed = parse_task(task)
        self.goal_manager.add_goal(parsed.goal)
        steps = build_steps(parsed)
        return Plan(goal=parsed.goal, parsed=parsed, steps=steps)