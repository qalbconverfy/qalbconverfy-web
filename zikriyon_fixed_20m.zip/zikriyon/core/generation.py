from __future__ import annotations

import torch


@torch.no_grad()
def greedy_generate(model, input_ids: torch.Tensor, max_new_tokens: int, eos_id: int | None = None) -> torch.Tensor:
    model.eval()
    out = input_ids
    for _ in range(max_new_tokens):
        logits = model(out)
        next_token = torch.argmax(logits[:, -1, :], dim=-1, keepdim=True)
        out = torch.cat([out, next_token], dim=-1)
        if eos_id is not None and torch.all(next_token == eos_id):
            break
    return out