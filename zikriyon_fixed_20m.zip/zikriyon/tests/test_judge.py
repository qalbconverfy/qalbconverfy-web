from zikriyon.judge.judge import Judge

def test_judge_output():
    result = Judge().evaluate("This is a valid response.")
    assert 0.0 <= result.score <= 1.0