"""
zikriyon/tokenizer/train_tokenizer.py
--------------------------------------
Stand-alone script to train the Zikriyon tokenizer on your corpus.

Usage
-----
    python -m zikriyon.tokenizer.train_tokenizer \
        --corpus data/raw/corpus.txt data/raw/code.txt \
        --vocab_size 8000 \
        --output tokenizer/zikriyon_tokenizer.json
"""

import argparse
from pathlib import Path
from .tokenizer import ZikriyonTokenizer


def main():
    parser = argparse.ArgumentParser(description="Train Zikriyon BPE tokenizer")
    parser.add_argument("--corpus", nargs="+", required=True, help="Text file(s) to train on")
    parser.add_argument("--vocab_size", type=int, default=8000)
    parser.add_argument("--output", type=str, default="tokenizer/zikriyon_tokenizer.json")
    args = parser.parse_args()

    # Verify corpus files exist
    for fpath in args.corpus:
        if not Path(fpath).exists():
            raise FileNotFoundError(f"Corpus file not found: {fpath}")

    tok = ZikriyonTokenizer(vocab_size=args.vocab_size)
    tok.train(args.corpus, verbose=True)
    tok.save(args.output)

    # Quick self-test
    test_text = "Hello, this is a test of the Zikriyon tokenizer."
    ids = tok.encode(test_text)
    dec = tok.decode(ids)
    print(f"\n[Test] Input  : {test_text}")
    print(f"[Test] Encoded: {ids[:20]}{'...' if len(ids) > 20 else ''}")
    print(f"[Test] Decoded: {dec}")
    print(f"\n[Done] Tokenizer saved to {args.output}")


if __name__ == "__main__":
    main()