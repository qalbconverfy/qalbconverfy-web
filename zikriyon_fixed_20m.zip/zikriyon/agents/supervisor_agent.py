from __future__ import annotations

from dataclasses import dataclass

from .chat_agent import ChatAgent


@dataclass
class SupervisorAgent:
    chat_agent: ChatAgent

    def handle(self, text: str) -> str:
        return self.chat_agent.respond(text)