from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, List, Tuple
import json
import re


@dataclass
class TokenizerConfig:
    vocab_size: int = 32000
    special_tokens: List[str] = field(
        default_factory=lambda: ["<pad>", "<bos>", "<eos>", "<unk>", "<tool>", "<memory>"]
    )
    regex_pattern: str = r"w+|[^ws]|s+"
    lowercase: bool = False


class ByteBPETokenizer:
    def __init__(
        self,
        config: TokenizerConfig | None = None,
        vocab: Dict[str, int] | None = None,
        merges: Dict[Tuple[str, str], int] | None = None,
    ) -> None:
        self.config = config or TokenizerConfig()
        self.vocab: Dict[str, int] = vocab or {}
        self.merges: Dict[Tuple[str, str], int] = merges or {}
        self.id_to_token: Dict[int, str] = {v: k for k, v in self.vocab.items()}
        self._compiled_pattern = re.compile(self.config.regex_pattern)

        if not self.vocab:
            self._initialize_base_vocab()

    def _initialize_base_vocab(self) -> None:
        self.vocab = {}
        idx = 0
        for token in self.config.special_tokens:
            self.vocab[token] = idx
            idx += 1

        for i in range(256):
            token = bytes([i]).decode("latin-1")
            if token not in self.vocab:
                self.vocab[token] = idx
                idx += 1

        self.id_to_token = {v: k for k, v in self.vocab.items()}

    def _normalize(self, text: str) -> str:
        return text.lower() if self.config.lowercase else text

    def _pretokenize(self, text: str) -> List[str]:
        return self._compiled_pattern.findall(text)

    def _token_bytes(self, piece: str) -> List[str]:
        return [bytes([b]).decode("latin-1") for b in piece.encode("utf-8")]

    @staticmethod
    def _pair_stats(symbols: List[str]) -> Dict[Tuple[str, str], int]:
        stats: Dict[Tuple[str, str], int] = {}
        for a, b in zip(symbols[:-1], symbols[1:]):
            stats[(a, b)] = stats.get((a, b), 0) + 1
        return stats

    @staticmethod
    def _merge_symbols(symbols: List[str], pair: Tuple[str, str], merged: str) -> List[str]:
        out: List[str] = []
        i = 0
        while i < len(symbols):
            if i < len(symbols) - 1 and (symbols[i], symbols[i + 1]) == pair:
                out.append(merged)
                i += 2
            else:
                out.append(symbols[i])
                i += 1
        return out

    def train(self, texts: Iterable[str], target_vocab_size: int | None = None) -> None:
        target_vocab_size = target_vocab_size or self.config.vocab_size
        corpus_tokens: List[List[str]] = []
        for text in texts:
            text = self._normalize(text)
            for piece in self._pretokenize(text):
                corpus_tokens.append(self._token_bytes(piece))

        next_id = max(self.vocab.values(), default=-1) + 1
        merges_applied = 0

        while len(self.vocab) < target_vocab_size:
            pair_counts: Dict[Tuple[str, str], int] = {}
            for symbols in corpus_tokens:
                for pair, count in self._pair_stats(symbols).items():
                    pair_counts[pair] = pair_counts.get(pair, 0) + count

            if not pair_counts:
                break

            best_pair = max(pair_counts.items(), key=lambda kv: kv[1])[0]
            merged_token = "".join(best_pair)

            if merged_token in self.vocab:
                break

            self.vocab[merged_token] = next_id
            self.merges[best_pair] = merges_applied
            next_id += 1
            merges_applied += 1

            updated: List[List[str]] = []
            for symbols in corpus_tokens:
                updated.append(self._merge_symbols(symbols, best_pair, merged_token))
            corpus_tokens = updated

        self.id_to_token = {v: k for k, v in self.vocab.items()}

    def encode(self, text: str, add_bos: bool = False, add_eos: bool = False) -> List[int]:
        text = self._normalize(text)
        pieces = self._pretokenize(text)
        tokens: List[int] = []

        if add_bos and "<bos>" in self.vocab:
            tokens.append(self.vocab["<bos>"])

        for piece in pieces:
            symbols = self._token_bytes(piece)
            changed = True
            while changed and len(symbols) > 1:
                changed = False
                best_idx = None
                best_pair = None
                for i, pair in enumerate(zip(symbols[:-1], symbols[1:])):
                    if pair in self.merges:
                        pair_rank = self.merges[pair]
                        if best_idx is None or pair_rank < best_idx:
                            best_idx = pair_rank
                            best_pair = pair
                if best_pair is not None:
                    merged = "".join(best_pair)
                    symbols = self._merge_symbols(symbols, best_pair, merged)
                    changed = True

            for symbol in symbols:
                token_id = self.vocab.get(symbol, self.vocab.get("<unk>", 0))
                tokens.append(token_id)

        if add_eos and "<eos>" in self.vocab:
            tokens.append(self.vocab["<eos>"])

        return tokens

    def decode(self, tokens: List[int], skip_special_tokens: bool = True) -> str:
        pieces: List[str] = []
        special = set(self.config.special_tokens) if skip_special_tokens else set()

        for token_id in tokens:
            token = self.id_to_token.get(token_id, "<unk>")
            if skip_special_tokens and token in special:
                continue
            pieces.append(token)

        raw = "".join(pieces)
        return raw.encode("latin-1").decode("utf-8", errors="replace")

    def save(self, path: str | Path) -> None:
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        (path / "vocab.json").write_text(json.dumps(self.vocab, ensure_ascii=False, indent=2), encoding="utf-8")
        merges_data = [
            {"left": left, "right": right, "rank": rank}
            for (left, right), rank in sorted(self.merges.items(), key=lambda kv: kv[1])
        ]
        (path / "merges.json").write_text(json.dumps(merges_data, ensure_ascii=False, indent=2), encoding="utf-8")
        (path / "tokenizer_config.json").write_text(
            json.dumps(self.config.__dict__, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, path: str | Path) -> "ByteBPETokenizer":
        path = Path(path)
        vocab = json.loads((path / "vocab.json").read_text(encoding="utf-8"))
        merges_raw = json.loads((path / "merges.json").read_text(encoding="utf-8"))
        config_data = json.loads((path / "tokenizer_config.json").read_text(encoding="utf-8"))

        merges = {(row["left"], row["right"]): int(row["rank"]) for row in merges_raw}
        config = TokenizerConfig(**config_data)
        return cls(config=config, vocab={k: int(v) for k, v in vocab.items()}, merges=merges)