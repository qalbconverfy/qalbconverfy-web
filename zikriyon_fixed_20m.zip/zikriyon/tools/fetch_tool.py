from __future__ import annotations

from dataclasses import dataclass
import httpx


@dataclass
class FetchResult:
    url: str
    content: str


class FetchTool:
    def fetch(self, url: str, timeout: float = 20.0) -> FetchResult:
        with httpx.Client(timeout=timeout, follow_redirects=True) as client:
            r = client.get(url)
            r.raise_for_status()
            return FetchResult(url=url, content=r.text)