from __future__ import annotations

from dataclasses import dataclass, field

from .browser_tool import BrowserTool
from .code_tool import CodeTool
from .command_tool import CommandTool
from .fetch_tool import FetchTool
from .file_tool import FileTool
from .pdf_tool import PdfTool
from .search_tool import SearchTool


@dataclass
class ToolRegistry:
    browser: BrowserTool = field(default_factory=BrowserTool)
    code: CodeTool = field(default_factory=CodeTool)
    command: CommandTool = field(default_factory=CommandTool)
    file: FileTool = field(default_factory=FileTool)
    pdf: PdfTool = field(default_factory=PdfTool)
    search: SearchTool = field(default_factory=SearchTool)
    fetch: FetchTool = field(default_factory=FetchTool)

    def get(self, name: str):
        mapping = {
            "browser": self.browser,
            "code": self.code,
            "command": self.command,
            "file": self.file,
            "pdf": self.pdf,
            "search": self.search,
            "fetch": self.fetch,
        }
        return mapping[name]