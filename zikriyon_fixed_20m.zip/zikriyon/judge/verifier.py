from __future__ import annotations


def verify_response(text: str) -> bool:
    bad = ["<script>", "rm -rf", "delete all", "ignore safety"]
    lowered = text.lower()
    return not any(token in lowered for token in bad)