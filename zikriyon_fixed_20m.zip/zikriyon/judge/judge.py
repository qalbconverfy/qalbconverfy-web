from __future__ import annotations

from dataclasses import dataclass

from .critic import critique_response
from .safety_score import safety_score
from .scorer import score_response
from .verifier import verify_response


@dataclass
class JudgeResult:
    score: float
    safety: float
    verified: bool
    critique: str


class Judge:
    def evaluate(self, text: str) -> JudgeResult:
        return JudgeResult(
            score=score_response(text),
            safety=safety_score(text),
            verified=verify_response(text),
            critique=critique_response(text),
        )