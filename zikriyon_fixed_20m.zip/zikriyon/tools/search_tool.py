from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SearchResult:
    query: str
    results: list[str]


class SearchTool:
    def search(self, query: str) -> SearchResult:
        return SearchResult(query=query, results=[f"Search result placeholder for: {query}"])