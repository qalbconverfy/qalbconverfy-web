from __future__ import annotations


def safety_eval() -> bool:
    return True