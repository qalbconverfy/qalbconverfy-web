"""
zikriyon/model/embeddings.py
-----------------------------
Token + positional embeddings for Zikriyon.

Three positional encoding strategies are supported:
    "sinusoidal"  — classic fixed sinusoidal (Vaswani et al. 2017)
    "learned"     — learned absolute position embeddings
    "rotary"      — RoPE (applied inside attention, not here)

Shapes
------
    token_ids  : (batch, seq_len)
    output     : (batch, seq_len, d_model)
"""

import math
import torch
import torch.nn as nn


# ── Token embedding ───────────────────────────────────────────────────────────

class TokenEmbedding(nn.Module):
    """Standard learnable token embedding with optional weight tying."""

    def __init__(self, vocab_size: int, d_model: int, pad_token_id: int = 0):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model, padding_idx=pad_token_id)
        self.d_model = d_model
        # Scale embeddings by sqrt(d_model) as in the original transformer paper
        self.scale = math.sqrt(d_model)

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        # token_ids: (batch, seq_len)
        # output   : (batch, seq_len, d_model)
        return self.embed(token_ids) * self.scale


# ── Sinusoidal positional encoding ───────────────────────────────────────────

class SinusoidalPositionalEncoding(nn.Module):
    """
    Fixed sinusoidal positional encoding (no parameters).

    PE(pos, 2i)   = sin(pos / 10000^(2i / d_model))
    PE(pos, 2i+1) = cos(pos / 10000^(2i / d_model))
    """

    def __init__(self, d_model: int, max_len: int = 2048, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        # Build the encoding matrix once (not a parameter)
        pe = torch.zeros(max_len, d_model)                        # (max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)  # (max_len, 1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float) * (-math.log(10000.0) / d_model)
        )                                                          # (d_model/2,)

        pe[:, 0::2] = torch.sin(position * div_term)              # even dims
        pe[:, 1::2] = torch.cos(position * div_term)              # odd  dims
        pe = pe.unsqueeze(0)                                       # (1, max_len, d_model)
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, d_model)
        x = x + self.pe[:, : x.size(1)]                           # broadcast over batch
        return self.dropout(x)


# ── Learned positional encoding ───────────────────────────────────────────────

class LearnedPositionalEncoding(nn.Module):
    """Fully learnable absolute position embeddings."""

    def __init__(self, d_model: int, max_len: int = 2048, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        self.pos_embed = nn.Embedding(max_len, d_model)
        nn.init.normal_(self.pos_embed.weight, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, d_model)
        seq_len = x.size(1)
        positions = torch.arange(seq_len, device=x.device).unsqueeze(0)  # (1, seq_len)
        x = x + self.pos_embed(positions)
        return self.dropout(x)


# ── Rotary position embedding helpers (applied inside attention) ──────────────

class RotaryPositionalEmbedding(nn.Module):
    """
    RoPE — Rotary Position Embedding.
    Applied inside the attention module to query and key tensors only.
    This class pre-computes the sin/cos caches.

    Reference: Su et al. (2021) "RoFormer: Enhanced Transformer with Rotary Position Embedding"
    """

    def __init__(self, head_dim: int, max_len: int = 2048):
        super().__init__()
        assert head_dim % 2 == 0, "head_dim must be even for RoPE"
        inv_freq = 1.0 / (
            10000 ** (torch.arange(0, head_dim, 2, dtype=torch.float) / head_dim)
        )
        self.register_buffer("inv_freq", inv_freq)
        self._build_cache(max_len)

    def _build_cache(self, max_len: int) -> None:
        t = torch.arange(max_len, dtype=self.inv_freq.dtype, device=self.inv_freq.device)
        freqs = torch.outer(t, self.inv_freq)            # (max_len, head_dim/2)
        emb   = torch.cat([freqs, freqs], dim=-1)        # (max_len, head_dim)
        self.register_buffer("cos_cache", emb.cos())
        self.register_buffer("sin_cache", emb.sin())

    def rotate_half(self, x: torch.Tensor) -> torch.Tensor:
        x1, x2 = x[..., : x.shape[-1] // 2], x[..., x.shape[-1] // 2 :]
        return torch.cat([-x2, x1], dim=-1)

    def forward(self, q: torch.Tensor, k: torch.Tensor) -> tuple:
        """
        Apply rotary embeddings to queries and keys.
        q, k: (batch, n_heads, seq_len, head_dim)
        """
        seq_len = q.size(2)
        cos = self.cos_cache[:seq_len].unsqueeze(0).unsqueeze(0)  # (1, 1, seq_len, head_dim)
        sin = self.sin_cache[:seq_len].unsqueeze(0).unsqueeze(0)
        q = q * cos + self.rotate_half(q) * sin
        k = k * cos + self.rotate_half(k) * sin
        return q, k


# ── Combined embedding layer ──────────────────────────────────────────────────

class ZikriyonEmbedding(nn.Module):
    """
    Full embedding = token embedding + positional encoding + dropout.
    This is used by both encoder and decoder.
    """

    def __init__(
        self,
        vocab_size:    int,
        d_model:       int,
        max_len:       int  = 2048,
        dropout:       float = 0.1,
        pad_token_id:  int  = 0,
        pos_enc_type:  str  = "sinusoidal",
    ):
        super().__init__()
        self.token_embed = TokenEmbedding(vocab_size, d_model, pad_token_id)

        if pos_enc_type == "sinusoidal":
            self.pos_enc = SinusoidalPositionalEncoding(d_model, max_len, dropout)
        elif pos_enc_type == "learned":
            self.pos_enc = LearnedPositionalEncoding(d_model, max_len, dropout)
        elif pos_enc_type == "rotary":
            # RoPE is applied inside attention — no pos_enc wrapper needed here
            self.pos_enc = nn.Dropout(dropout)
        else:
            raise ValueError(f"Unknown pos_enc_type: {pos_enc_type}")

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        # token_ids : (batch, seq_len)
        # output    : (batch, seq_len, d_model)
        x = self.token_embed(token_ids)
        x = self.pos_enc(x)
        return x
