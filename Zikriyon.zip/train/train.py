"""
zikriyon/train/train.py
------------------------
Entry-point script for training Zikriyon.

Usage
-----
    # Tiny overfit test (CPU, no real data)
    python -m zikriyon.train.train --mode overfit

    # Small real training
    python -m zikriyon.train.train \
        --data_path data/paired.jsonl \
        --tokenizer_path tokenizer/zikriyon_tokenizer.json \
        --config small \
        --resume checkpoints/zikriyon_epoch005.pt  # optional
"""

import argparse
import random
import torch

from ..config       import ZikriyonConfig, tiny_config, small_config, base_config
from ..model        import ZikriyonModel
from ..tokenizer    import ZikriyonTokenizer
from ..data         import (
    load_paired_jsonl, load_instruction_jsonl, load_text_file,
    split_samples, build_dataloaders,
)
from .trainer       import ZikriyonTrainer


def make_dummy_samples(n: int = 64) -> list:
    """Create tiny dummy pairs for overfit sanity check."""
    return [
        {"src": f"The number is {i}.", "tgt": f"Number: {i}."}
        for i in range(n)
    ]


def make_dummy_tokenizer(vocab_size: int = 256) -> ZikriyonTokenizer:
    """Create a minimal tokenizer for overfit test (no real corpus needed)."""
    import tempfile, os
    tok = ZikriyonTokenizer(vocab_size=vocab_size)
    # Write a tiny corpus to a temp file and train on it
    corpus_text = "\n".join(
        [f"The number is {i}. Number: {i}." for i in range(200)]
        + ["Hello world. This is a test. Code: print('hello')."]
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
        f.write(corpus_text)
        tmp = f.name
    tok.train([tmp], verbose=False)
    os.unlink(tmp)
    return tok


def main():
    parser = argparse.ArgumentParser(description="Train Zikriyon")
    parser.add_argument("--mode", choices=["overfit", "train"], default="train")
    parser.add_argument("--config", choices=["tiny", "small", "base"], default="small")
    parser.add_argument("--data_path", type=str, default=None,
                        help="Path to .jsonl data file")
    parser.add_argument("--data_type", choices=["paired", "instruction", "text"],
                        default="paired")
    parser.add_argument("--tokenizer_path", type=str, default=None,
                        help="Path to trained tokenizer JSON")
    parser.add_argument("--resume", type=str, default=None,
                        help="Path to checkpoint to resume from")
    parser.add_argument("--epochs", type=int, default=None)
    parser.add_argument("--batch_size", type=int, default=None)
    parser.add_argument("--device", type=str, default=None)
    args = parser.parse_args()

    # ── Config ──────────────────────────────────────────────────────────
    if args.config == "tiny":
        cfg = tiny_config()
    elif args.config == "small":
        cfg = small_config()
    else:
        cfg = base_config()

    if args.epochs:     cfg.max_epochs = args.epochs
    if args.batch_size: cfg.batch_size = args.batch_size
    if args.device:     cfg.device     = args.device

    # ── Overfit sanity test ──────────────────────────────────────────────
    if args.mode == "overfit":
        print("[Train] Running overfit sanity test on tiny dummy data...")
        cfg = tiny_config()
        cfg.max_epochs = 30
        cfg.batch_size = 4
        tokenizer = make_dummy_tokenizer(vocab_size=cfg.vocab_size)
        samples = make_dummy_samples(n=16)
        train_s, val_s, _ = split_samples(samples, train_frac=0.8, val_frac=0.2)
        train_loader, val_loader = build_dataloaders(
            train_s, val_s, tokenizer,
            max_src_len=cfg.max_src_len,
            max_tgt_len=cfg.max_tgt_len,
            batch_size=cfg.batch_size,
        )
        cfg.vocab_size = len(tokenizer)
        model = ZikriyonModel(cfg)
        trainer = ZikriyonTrainer(model, cfg, train_loader, val_loader)
        trainer.train()
        return

    # ── Real training ────────────────────────────────────────────────────
    if args.tokenizer_path is None or args.data_path is None:
        parser.error("--tokenizer_path and --data_path are required for train mode")

    tokenizer = ZikriyonTokenizer.load(args.tokenizer_path)
    cfg.vocab_size = len(tokenizer)

    if args.data_type == "paired":
        samples = load_paired_jsonl(args.data_path)
    elif args.data_type == "instruction":
        samples = load_instruction_jsonl(args.data_path)
    else:
        samples = load_text_file(args.data_path, max_seq_len=cfg.max_src_len)

    print(f"[Train] Loaded {len(samples)} samples from {args.data_path}")
    train_s, val_s, _ = split_samples(samples)

    train_loader, val_loader = build_dataloaders(
        train_s, val_s, tokenizer,
        max_src_len=cfg.max_src_len,
        max_tgt_len=cfg.max_tgt_len,
        batch_size=cfg.batch_size,
    )

    model = ZikriyonModel(cfg)
    trainer = ZikriyonTrainer(model, cfg, train_loader, val_loader, resume_from=args.resume)
    trainer.train()


if __name__ == "__main__":
    main()
