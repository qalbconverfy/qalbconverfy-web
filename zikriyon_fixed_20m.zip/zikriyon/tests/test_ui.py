from zikriyon.ui.app import build_demo

def test_ui_builds():
    demo = build_demo()
    assert demo is not None