from __future__ import annotations

from typing import List, Dict, Any


def keyword_retrieve(query: str, items: List[Dict[str, Any]], limit: int = 5) -> List[Dict[str, Any]]:
    q = query.lower()
    scored = []
    for item in items:
        text = " ".join(str(v) for v in item.values()).lower()
        score = sum(1 for token in q.split() if token in text)
        if score > 0:
            scored.append((score, item))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [item for _, item in scored[:limit]]