from __future__ import annotations

from dataclasses import dataclass


@dataclass
class PermissionResult:
    allowed: bool
    reason: str