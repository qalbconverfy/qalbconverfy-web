from setuptools import setup, find_packages

setup(
    name="zikriyon",
    version="0.1.0",
    description="Zikriyon — From-Scratch Encoder-Decoder Transformer",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "torch>=2.0.0",
        "numpy>=1.24.0",
    ],
)