from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ApprovedMemoryItem:
    key: str
    value: Any
    confidence: float = 1.0