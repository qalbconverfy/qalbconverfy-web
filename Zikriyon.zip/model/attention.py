"""
zikriyon/model/attention.py
----------------------------
Multi-Head Self-Attention for Zikriyon.

Supports:
    - encoder self-attention   (bidirectional, no mask needed)
    - decoder causal self-attention (with causal / look-ahead mask)

Shapes
------
    x          : (batch, seq_len, d_model)
    attn_mask  : (batch, 1, seq_len, seq_len)  or None
    output     : (batch, seq_len, d_model)

Attention formula:
    Attention(Q, K, V) = softmax(Q K^T / sqrt(d_k)) V
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class MultiHeadSelfAttention(nn.Module):
    """
    Multi-Head Self-Attention.

    Parameters
    ----------
    d_model   : total hidden size
    n_heads   : number of attention heads  (d_model must be divisible by n_heads)
    dropout   : attention dropout rate
    causal    : if True, apply causal (lower-triangular) mask  → decoder
    """

    def __init__(
        self,
        d_model:  int,
        n_heads:  int,
        dropout:  float = 0.1,
        causal:   bool  = False,
    ):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"

        self.d_model   = d_model
        self.n_heads   = n_heads
        self.head_dim  = d_model // n_heads   # d_k = d_v = d_model / n_heads
        self.causal    = causal
        self.scale     = math.sqrt(self.head_dim)

        # Projection matrices
        self.q_proj = nn.Linear(d_model, d_model, bias=False)
        self.k_proj = nn.Linear(d_model, d_model, bias=False)
        self.v_proj = nn.Linear(d_model, d_model, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)

        self.attn_drop = nn.Dropout(dropout)
        self.resid_drop = nn.Dropout(dropout)

        # Initialize with small weights
        self._init_weights()

    def _init_weights(self):
        for proj in [self.q_proj, self.k_proj, self.v_proj, self.out_proj]:
            nn.init.xavier_uniform_(proj.weight)

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        """
        Reshape (batch, seq, d_model) → (batch, n_heads, seq, head_dim)
        """
        batch, seq_len, _ = x.shape
        x = x.view(batch, seq_len, self.n_heads, self.head_dim)
        return x.transpose(1, 2)   # (batch, n_heads, seq_len, head_dim)

    def _merge_heads(self, x: torch.Tensor) -> torch.Tensor:
        """
        Reshape (batch, n_heads, seq, head_dim) → (batch, seq, d_model)
        """
        batch, _, seq_len, _ = x.shape
        x = x.transpose(1, 2).contiguous()
        return x.view(batch, seq_len, self.d_model)

    def _causal_mask(self, seq_len: int, device: torch.device) -> torch.Tensor:
        """
        Lower-triangular causal mask.
        True  = attend to this position
        False = mask it out (set to -inf before softmax)
        Shape: (1, 1, seq_len, seq_len)
        """
        mask = torch.tril(torch.ones(seq_len, seq_len, device=device, dtype=torch.bool))
        return mask.unsqueeze(0).unsqueeze(0)   # broadcast over batch and heads

    def forward(
        self,
        x:         torch.Tensor,                    # (batch, seq_len, d_model)
        attn_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, seq_len) padding mask
    ) -> torch.Tensor:
        batch, seq_len, _ = x.shape

        # Project → Q, K, V
        q = self._split_heads(self.q_proj(x))   # (batch, n_heads, seq_len, head_dim)
        k = self._split_heads(self.k_proj(x))
        v = self._split_heads(self.v_proj(x))

        # Scaled dot-product attention scores
        scores = torch.matmul(q, k.transpose(-2, -1)) / self.scale
        # scores: (batch, n_heads, seq_len, seq_len)

        # Apply causal mask for decoder self-attention
        if self.causal:
            causal = self._causal_mask(seq_len, x.device)
            scores = scores.masked_fill(~causal, float("-inf"))

        # Apply padding mask (attn_mask = 0 means padded position)
        if attn_mask is not None:
            # attn_mask: (batch, 1, 1, seq_len) — broadcast to (batch, n_heads, seq_len, seq_len)
            scores = scores.masked_fill(attn_mask == 0, float("-inf"))

        # Softmax + dropout
        attn_weights = F.softmax(scores, dim=-1)
        # Guard against all-masked rows (NaN → 0)
        attn_weights = torch.nan_to_num(attn_weights, nan=0.0)
        attn_weights = self.attn_drop(attn_weights)

        # Weighted sum of values
        out = torch.matmul(attn_weights, v)         # (batch, n_heads, seq_len, head_dim)
        out = self._merge_heads(out)                # (batch, seq_len, d_model)
        out = self.out_proj(out)
        out = self.resid_drop(out)

        return out                                   # (batch, seq_len, d_model)
