"""
zikriyon/model/cross_attention.py
----------------------------------
Multi-Head Cross-Attention for Zikriyon.

Used in each decoder layer to attend to encoder hidden states.

Shapes
------
    x              : (batch, tgt_len, d_model)   — decoder queries
    enc_out        : (batch, src_len, d_model)   — encoder key/value
    enc_mask       : (batch, 1, 1, src_len)      — 0 = pad position in source
    output         : (batch, tgt_len, d_model)
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional


class MultiHeadCrossAttention(nn.Module):
    """
    Multi-Head Cross-Attention.

    Queries come from the decoder (x).
    Keys and Values come from encoder output (enc_out).
    This lets the decoder look at the full encoder memory at every decoder step.

    Parameters
    ----------
    d_model  : hidden size (must match encoder and decoder d_model)
    n_heads  : number of attention heads
    dropout  : attention and residual dropout
    """

    def __init__(
        self,
        d_model: int,
        n_heads: int,
        dropout: float = 0.1,
    ):
        super().__init__()
        assert d_model % n_heads == 0

        self.d_model  = d_model
        self.n_heads  = n_heads
        self.head_dim = d_model // n_heads
        self.scale    = math.sqrt(self.head_dim)

        # Queries from decoder, Keys/Values from encoder
        self.q_proj   = nn.Linear(d_model, d_model, bias=False)
        self.k_proj   = nn.Linear(d_model, d_model, bias=False)
        self.v_proj   = nn.Linear(d_model, d_model, bias=False)
        self.out_proj = nn.Linear(d_model, d_model, bias=False)

        self.attn_drop  = nn.Dropout(dropout)
        self.resid_drop = nn.Dropout(dropout)

        self._init_weights()

    def _init_weights(self):
        for proj in [self.q_proj, self.k_proj, self.v_proj, self.out_proj]:
            nn.init.xavier_uniform_(proj.weight)

    def _split_heads(self, x: torch.Tensor) -> torch.Tensor:
        """(batch, seq, d_model) → (batch, n_heads, seq, head_dim)"""
        b, s, _ = x.shape
        return x.view(b, s, self.n_heads, self.head_dim).transpose(1, 2)

    def _merge_heads(self, x: torch.Tensor) -> torch.Tensor:
        """(batch, n_heads, seq, head_dim) → (batch, seq, d_model)"""
        b, _, s, _ = x.shape
        return x.transpose(1, 2).contiguous().view(b, s, self.d_model)

    def forward(
        self,
        x:        torch.Tensor,                    # decoder hidden: (batch, tgt_len, d_model)
        enc_out:  torch.Tensor,                    # encoder output: (batch, src_len, d_model)
        enc_mask: Optional[torch.Tensor] = None,   # encoder padding mask: (batch,1,1,src_len)
    ) -> torch.Tensor:

        # Queries from decoder, Keys/Values from encoder
        q = self._split_heads(self.q_proj(x))        # (batch, n_heads, tgt_len, head_dim)
        k = self._split_heads(self.k_proj(enc_out))  # (batch, n_heads, src_len, head_dim)
        v = self._split_heads(self.v_proj(enc_out))  # (batch, n_heads, src_len, head_dim)

        # Scaled dot-product: Q x K^T
        scores = torch.matmul(q, k.transpose(-2, -1)) / self.scale
        # scores: (batch, n_heads, tgt_len, src_len)

        # Mask out encoder padding positions
        if enc_mask is not None:
            # enc_mask: (batch, 1, 1, src_len) → broadcast
            scores = scores.masked_fill(enc_mask == 0, float("-inf"))

        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = torch.nan_to_num(attn_weights, nan=0.0)
        attn_weights = self.attn_drop(attn_weights)

        # Weighted sum of encoder value vectors
        out = torch.matmul(attn_weights, v)          # (batch, n_heads, tgt_len, head_dim)
        out = self._merge_heads(out)                 # (batch, tgt_len, d_model)
        out = self.out_proj(out)
        out = self.resid_drop(out)

        return out                                    # (batch, tgt_len, d_model)
