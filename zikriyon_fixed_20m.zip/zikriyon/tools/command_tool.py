from __future__ import annotations

from dataclasses import dataclass
import subprocess


@dataclass
class CommandResult:
    stdout: str
    stderr: str
    returncode: int


class CommandTool:
    def run(self, command: list[str], cwd: str | None = None, timeout: int = 30) -> CommandResult:
        proc = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return CommandResult(stdout=proc.stdout, stderr=proc.stderr, returncode=proc.returncode)