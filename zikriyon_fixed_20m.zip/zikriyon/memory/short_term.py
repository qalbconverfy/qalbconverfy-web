from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Deque, List


@dataclass
class ShortTermMemory:
    max_items: int = 32
    items: Deque[str] = field(default_factory=deque)

    def add(self, item: str) -> None:
        self.items.append(item)
        while len(self.items) > self.max_items:
            self.items.popleft()

    def list(self) -> List[str]:
        return list(self.items)

    def clear(self) -> None:
        self.items.clear()