from zikriyon.tokenizer.tokenizer import ByteBPETokenizer, TokenizerConfig

def test_tokenizer_roundtrip():
    tok = ByteBPETokenizer(TokenizerConfig(vocab_size=300))
    text = "Hello world!"
    ids = tok.encode(text)
    assert isinstance(ids, list)
    assert len(ids) > 0
    assert isinstance(tok.decode(ids), str)