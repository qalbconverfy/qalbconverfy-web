from __future__ import annotations

from dataclasses import dataclass


@dataclass
class BrowserResult:
    url: str
    content: str


class BrowserTool:
    def open(self, url: str) -> BrowserResult:
        return BrowserResult(url=url, content=f"Opened browser at {url}")