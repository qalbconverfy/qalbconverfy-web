"""
zikriyon/config/config.py
--------------------------
Central configuration for the Zikriyon model.
All hyperparameters live here. Change this file to scale the model.
"""

from dataclasses import dataclass, field, asdict
import json
from pathlib import Path


@dataclass
class ZikriyonConfig:
    # ── Model identity ───────────────────────────────────────────────────
    model_name: str = "Zikriyon"
    version: str = "0.1.0"

    # ── Vocabulary / tokenizer ───────────────────────────────────────────
    vocab_size: int = 8000          # set after tokenizer is trained
    pad_token_id: int = 0
    bos_token_id: int = 1
    eos_token_id: int = 2
    unk_token_id: int = 3

    # ── Sequence lengths ────────────────────────────────────────────────
    max_src_len: int = 512          # encoder context
    max_tgt_len: int = 512          # decoder context

    # ── Model dimensions ────────────────────────────────────────────────
    d_model: int = 512              # hidden / embedding size
    d_ff: int = 2048               # feed-forward inner size
    n_heads: int = 8               # attention heads  (d_model % n_heads == 0)
    n_enc_layers: int = 6          # encoder transformer blocks
    n_dec_layers: int = 6          # decoder transformer blocks
    dropout: float = 0.1

    # ── Positional encoding ─────────────────────────────────────────────
    pos_enc_type: str = "sinusoidal"   # "sinusoidal" | "learned" | "rotary"

    # ── Training ────────────────────────────────────────────────────────
    batch_size: int = 32
    learning_rate: float = 1e-4
    weight_decay: float = 0.01
    max_epochs: int = 20
    warmup_steps: int = 4000
    grad_clip: float = 1.0
    label_smoothing: float = 0.1
    seed: int = 42

    # ── Checkpointing ───────────────────────────────────────────────────
    checkpoint_dir: str = "checkpoints"
    save_every_n_epochs: int = 1
    keep_best_n: int = 3

    # ── Logging ─────────────────────────────────────────────────────────
    log_dir: str = "logs"
    log_every_n_steps: int = 50

    # ── Inference / sampling ────────────────────────────────────────────
    max_gen_len: int = 256
    temperature: float = 1.0
    top_k: int = 50
    top_p: float = 0.9

    # ── Device ──────────────────────────────────────────────────────────
    device: str = "cuda"            # "cuda" | "cpu"

    # ── Future flags (set False until implemented) ───────────────────────
    use_retrieval: bool = False
    use_flash_attention: bool = False
    use_rope: bool = False          # switch positional encoding to RoPE

    # ────────────────────────────────────────────────────────────────────

    def save(self, path: str | Path) -> None:
        """Persist config as JSON."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)
        print(f"[ZikriyonConfig] saved → {path}")

    @classmethod
    def load(cls, path: str | Path) -> "ZikriyonConfig":
        """Load config from JSON."""
        with open(path) as f:
            data = json.load(f)
        cfg = cls(**data)
        print(f"[ZikriyonConfig] loaded ← {path}")
        return cfg

    def __post_init__(self):
        assert self.d_model % self.n_heads == 0, (
            f"d_model ({self.d_model}) must be divisible by n_heads ({self.n_heads})"
        )
        assert self.pos_enc_type in ("sinusoidal", "learned", "rotary"), (
            f"Unknown pos_enc_type: {self.pos_enc_type}"
        )


# ── Preset configs ────────────────────────────────────────────────────────────

def tiny_config() -> ZikriyonConfig:
    """Tiny config for overfit sanity tests on CPU."""
    return ZikriyonConfig(
        vocab_size=1000,
        d_model=128,
        d_ff=512,
        n_heads=4,
        n_enc_layers=2,
        n_dec_layers=2,
        max_src_len=64,
        max_tgt_len=64,
        batch_size=4,
        max_epochs=5,
        device="cpu",
    )


def small_config() -> ZikriyonConfig:
    """Small config for real training on modest hardware."""
    return ZikriyonConfig(
        vocab_size=8000,
        d_model=256,
        d_ff=1024,
        n_heads=4,
        n_enc_layers=4,
        n_dec_layers=4,
        max_src_len=256,
        max_tgt_len=256,
        batch_size=16,
        device="cuda",
    )


def base_config() -> ZikriyonConfig:
    """Base config — the default Zikriyon-Base model."""
    return ZikriyonConfig()