"""
zikriyon/model/encoder.py
--------------------------
Encoder stack for Zikriyon.

Architecture per layer (pre-norm style):
    x → LayerNorm → MultiHeadSelfAttention → residual
      → LayerNorm → FeedForward            → residual

Full encoder:
    token_ids → Embedding → N × EncoderLayer → final LayerNorm → hidden states

Shapes
------
    src_ids   : (batch, src_len)
    src_mask  : (batch, src_len)          — 1 = real token, 0 = pad
    output    : (batch, src_len, d_model) — contextual hidden states
"""

import torch
import torch.nn as nn
from typing import Optional

from .embeddings import ZikriyonEmbedding
from .attention  import MultiHeadSelfAttention
from .norms      import LayerNorm


# ── Feed-Forward block ────────────────────────────────────────────────────────

class FeedForward(nn.Module):
    """
    Position-wise Feed-Forward Network.

    FFN(x) = GELU(x W_1 + b_1) W_2 + b_2

    Uses GELU activation (better than ReLU for language tasks).
    Shape: (batch, seq_len, d_model) → (batch, seq_len, d_model)
    """

    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout),
        )
        self._init_weights()

    def _init_weights(self):
        for layer in self.net:
            if isinstance(layer, nn.Linear):
                nn.init.xavier_uniform_(layer.weight)
                nn.init.zeros_(layer.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


# ── Single encoder layer ──────────────────────────────────────────────────────

class EncoderLayer(nn.Module):
    """
    One Transformer encoder layer (pre-norm).

    Sub-layers:
        1. Self-Attention  (bidirectional, no causal mask)
        2. Feed-Forward

    Each sub-layer: output = input + SubLayer(LayerNorm(input))
    """

    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.norm1 = LayerNorm(d_model)
        self.norm2 = LayerNorm(d_model)

        self.self_attn = MultiHeadSelfAttention(
            d_model=d_model,
            n_heads=n_heads,
            dropout=dropout,
            causal=False,        # encoder is bidirectional
        )
        self.ff = FeedForward(d_model, d_ff, dropout)

    def forward(
        self,
        x:        torch.Tensor,                    # (batch, src_len, d_model)
        src_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, src_len)
    ) -> torch.Tensor:

        # Sub-layer 1: self-attention with pre-norm + residual
        residual = x
        x = self.norm1(x)
        x = self.self_attn(x, attn_mask=src_mask)
        x = residual + x

        # Sub-layer 2: feed-forward with pre-norm + residual
        residual = x
        x = self.norm2(x)
        x = self.ff(x)
        x = residual + x

        return x    # (batch, src_len, d_model)


# ── Full encoder ──────────────────────────────────────────────────────────────

class ZikriyonEncoder(nn.Module):
    """
    Full Zikriyon encoder stack.

    Pipeline:
        src_ids → Embedding → N × EncoderLayer → LayerNorm → enc_hidden_states

    Parameters
    ----------
    vocab_size   : tokenizer vocabulary size
    d_model      : hidden / embedding size
    n_heads      : number of attention heads
    d_ff         : feed-forward inner size
    n_layers     : number of encoder transformer blocks
    max_src_len  : maximum source sequence length
    dropout      : dropout rate
    pad_token_id : id of the padding token
    pos_enc_type : "sinusoidal" | "learned" | "rotary"
    """

    def __init__(
        self,
        vocab_size:   int,
        d_model:      int,
        n_heads:      int,
        d_ff:         int,
        n_layers:     int,
        max_src_len:  int   = 512,
        dropout:      float = 0.1,
        pad_token_id: int   = 0,
        pos_enc_type: str   = "sinusoidal",
    ):
        super().__init__()

        self.embedding = ZikriyonEmbedding(
            vocab_size   = vocab_size,
            d_model      = d_model,
            max_len      = max_src_len,
            dropout      = dropout,
            pad_token_id = pad_token_id,
            pos_enc_type = pos_enc_type,
        )

        self.layers = nn.ModuleList([
            EncoderLayer(d_model, n_heads, d_ff, dropout)
            for _ in range(n_layers)
        ])

        self.final_norm = LayerNorm(d_model)

    @staticmethod
    def make_src_mask(src_ids: torch.Tensor, pad_token_id: int) -> torch.Tensor:
        """
        Create padding mask for encoder.
        1 = real token, 0 = pad.
        Shape: (batch, 1, 1, src_len)  — broadcast to (batch, n_heads, src_len, src_len)
        """
        return (src_ids != pad_token_id).unsqueeze(1).unsqueeze(2)

    def forward(
        self,
        src_ids:  torch.Tensor,                    # (batch, src_len)
        src_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, src_len)
    ) -> torch.Tensor:

        # (batch, src_len) → (batch, src_len, d_model)
        x = self.embedding(src_ids)

        # Pass through N encoder layers
        for layer in self.layers:
            x = layer(x, src_mask=src_mask)

        # Final layer norm
        x = self.final_norm(x)

        return x    # (batch, src_len, d_model) — encoder hidden states
