from __future__ import annotations

from dataclasses import dataclass, field

from .lifecycle import Lifecycle
from .state_machine import StateMachine


@dataclass
class WorkflowEngine:
    lifecycle: Lifecycle = field(default_factory=Lifecycle)
    state_machine: StateMachine = field(default_factory=StateMachine)

    def start(self) -> None:
        self.lifecycle.start()
        self.state_machine.transition("running")

    def stop(self) -> None:
        self.lifecycle.stop()
        self.state_machine.transition("stopped")