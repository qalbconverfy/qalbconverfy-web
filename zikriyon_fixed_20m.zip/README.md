# Zikriyon

Zikriyon is a production-grade, AGI-style local assistant that can chat, plan tasks, use tools, browse the web, execute code, create PDFs, manage files, remember context, self-evaluate, and improve through supervised online learning.

## Features

| Feature | Status |
|---------|--------|
| Natural conversation | ✅ |
| Task planning & decomposition | ✅ |
| Tool routing | ✅ |
| Memory (short/long/approved) | ✅ |
| Self-evaluation / critic | ✅ |
| Web search & browser research | ✅ |
| Code execution & debugging | ✅ |
| PDF creation | ✅ |
| File read/write | ✅ |
| Safe shell execution | ✅ |
| Supervised online learning | ✅ |
| Audit logs & rollback | ✅ |
| Local demo UI | ✅ |
| Image generation | ❌ (disabled) |

## Quickstart

```bash
git clone https://github.com/yourname/zikriyon.git
cd zikriyon
python -m pip install -r requirements.txt
python -m pip install -e .
python -m zikriyon.inference.chat
python -m zikriyon.ui.app
# Open http://localhost:7860
python -m zikriyon.train.train --stage 0
python -m zikriyon.train.train --stage 1
python -m zikriyon.train.train --stage 2
python -m zikriyon.train.train --stage 3
python -m zikriyon.train.train --stage 4
python -m pytest tests -v
python -m zikriyon.eval.eval --suite smoke
python -m zikriyon.eval.eval --suite regression




zikriyon/
├── tokenizer/      # Tokenizer and tokenizer training
├── core/           # Model internals: embeddings, attention, decoder, FFN
├── planner/        # Task decomposition and goal management
├── router/         # Tool and model routing
├── memory/         # Short-term, long-term, approved memory
├── judge/          # Output quality and safety evaluation
├── safety/         # Policy gates, permissions, sandbox, audit
├── tools/          # Browser, code, PDF, file, command tools
├── agents/         # Higher-level composed workflows
├── train/          # Training pipelines and checkpointing
├── eval/           # Smoke tests, regression tests, benchmarks
├── inference/      # Chat loop, API, streaming, formatting
├── ui/             # Local demo UI
├── orchestration/  # Lifecycle and state machine
├── observability/  # Logging, metrics, tracing
├── data/           # Approved data, fixtures, and local stores
├── checkpoints/    # Stage checkpoints and best model
├── logs/           # Audit and runtime logs
├── prompts/        # System and tool prompts
└── tests/          # Unit and integration tests