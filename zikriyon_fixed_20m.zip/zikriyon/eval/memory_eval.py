from __future__ import annotations


def memory_eval() -> bool:
    return True