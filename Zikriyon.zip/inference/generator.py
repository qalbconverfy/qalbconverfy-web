"""
zikriyon/inference/generator.py
--------------------------------
Autoregressive text generation for Zikriyon.

Supports:
    - Greedy decoding
    - Temperature sampling
    - Top-k sampling
    - Top-p (nucleus) sampling

Usage
-----
    from zikriyon.inference import ZikriyonGenerator

    gen = ZikriyonGenerator(model, tokenizer, cfg)
    output = gen.generate("Translate to French: Hello, world!")
    print(output)
"""

import torch
import torch.nn.functional as F
from typing import List, Optional

from ..config    import ZikriyonConfig
from ..model     import ZikriyonModel
from ..tokenizer import ZikriyonTokenizer


class ZikriyonGenerator:
    """
    Autoregressive token-by-token generator for ZikriyonModel.

    Generation flow:
        1. Encode source text with encoder  →  enc_out
        2. Start decoder with [BOS]
        3. At each step, feed current tgt sequence to decoder → logits for next token
        4. Sample / argmax next token from logits
        5. Append to sequence and repeat until EOS or max_len
    """

    def __init__(
        self,
        model:     ZikriyonModel,
        tokenizer: ZikriyonTokenizer,
        cfg:       ZikriyonConfig,
        device:    Optional[str] = None,
    ):
        self.model     = model
        self.tokenizer = tokenizer
        self.cfg       = cfg
        self.device    = torch.device(device or cfg.device)
        self.model.to(self.device)
        self.model.eval()

    # ── Sampling helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _top_k_filter(logits: torch.Tensor, k: int) -> torch.Tensor:
        """Zero out all logits except the top-k."""
        if k <= 0:
            return logits
        threshold = torch.topk(logits, k).values[..., -1, None]
        return logits.masked_fill(logits < threshold, float("-inf"))

    @staticmethod
    def _top_p_filter(logits: torch.Tensor, p: float) -> torch.Tensor:
        """Nucleus (top-p) filtering: keep smallest set of tokens whose cumulative prob ≥ p."""
        if p >= 1.0:
            return logits
        sorted_logits, sorted_indices = torch.sort(logits, descending=True)
        cumprobs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
        # Remove tokens where cumulative prob exceeds p (shift right to keep first token)
        remove_mask = cumprobs - F.softmax(sorted_logits, dim=-1) > p
        sorted_logits[remove_mask] = float("-inf")
        # Scatter back to original ordering
        return logits.scatter(-1, sorted_indices, sorted_logits)

    def _sample_next_token(
        self,
        logits:      torch.Tensor,   # (1, vocab_size)  — logits at last position
        temperature: float,
        top_k:       int,
        top_p:       float,
    ) -> int:
        logits = logits.squeeze(0)                         # (vocab_size,)

        if temperature == 0.0:
            # Greedy
            return int(logits.argmax().item())

        logits = logits / temperature
        logits = self._top_k_filter(logits, top_k)
        logits = self._top_p_filter(logits, top_p)

        probs = F.softmax(logits, dim=-1)
        return int(torch.multinomial(probs, num_samples=1).item())

    # ── Core generate ────────────────────────────────────────────────────────

    @torch.no_grad()
    def generate(
        self,
        source_text: str,
        max_gen_len: Optional[int]  = None,
        temperature: Optional[float] = None,
        top_k:       Optional[int]   = None,
        top_p:       Optional[float] = None,
    ) -> str:
        """
        Generate a response for a given source text.

        Parameters
        ----------
        source_text : str   — the input text (encoder input)
        max_gen_len : int   — max tokens to generate (default from cfg)
        temperature : float — sampling temperature (0 = greedy)
        top_k       : int   — top-k filtering
        top_p       : float — nucleus filtering

        Returns
        -------
        str : decoded generated text (without BOS/EOS)
        """
        max_gen_len = max_gen_len or self.cfg.max_gen_len
        temperature = temperature if temperature is not None else self.cfg.temperature
        top_k       = top_k       if top_k       is not None else self.cfg.top_k
        top_p       = top_p       if top_p       is not None else self.cfg.top_p

        # Tokenize source
        src_ids = self.tokenizer.encode(
            source_text, add_bos=True, add_eos=True, max_length=self.cfg.max_src_len
        )
        src_tensor = torch.tensor([src_ids], dtype=torch.long, device=self.device)
        # src_tensor: (1, src_len)

        # Encode source once
        src_mask = self.model._make_src_mask(src_tensor)
        enc_out  = self.model.encoder(src_tensor, src_mask)
        # enc_out: (1, src_len, d_model)

        # Start decoding with BOS token
        generated  = [self.tokenizer.bos_token_id]
        eos_id     = self.tokenizer.eos_token_id

        for _ in range(max_gen_len):
            tgt_tensor = torch.tensor([generated], dtype=torch.long, device=self.device)
            # tgt_tensor: (1, current_len)

            tgt_mask = self.model._make_tgt_mask(tgt_tensor)
            dec_out  = self.model.decoder(tgt_tensor, enc_out,
                                          tgt_mask=tgt_mask, enc_mask=src_mask)
            # dec_out: (1, current_len, d_model)

            # Take logits at the LAST position only (next-token prediction)
            logits = self.model.lm_head(dec_out[:, -1:, :])   # (1, 1, vocab)
            logits = logits[:, 0, :]                            # (1, vocab)

            next_token = self._sample_next_token(logits, temperature, top_k, top_p)
            generated.append(next_token)

            if next_token == eos_id:
                break

        # Decode (skip BOS, strip EOS)
        output_ids = generated[1:]   # remove BOS
        if output_ids and output_ids[-1] == eos_id:
            output_ids = output_ids[:-1]

        return self.tokenizer.decode(output_ids, skip_special=True)

    # ── Batch generation ─────────────────────────────────────────────────────

    @torch.no_grad()
    def generate_batch(
        self,
        source_texts: List[str],
        max_gen_len:  Optional[int]   = None,
        temperature:  Optional[float] = None,
        top_k:        Optional[int]   = None,
        top_p:        Optional[float] = None,
    ) -> List[str]:
        """Generate for a list of source texts (one by one — simple version)."""
        return [
            self.generate(text, max_gen_len, temperature, top_k, top_p)
            for text in source_texts
        ]