from __future__ import annotations

import torch
from torch import nn


class Encoder(nn.Module):
    """Placeholder Encoder (currently not used — decoder-only model)."""
    def __init__(self, *args, **kwargs):
        super().__init__()
        pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x