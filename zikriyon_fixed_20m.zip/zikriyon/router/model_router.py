from __future__ import annotations


def select_model(task: str) -> str:
    text = task.lower()
    if any(k in text for k in ["code", "debug", "compute"]):
        return "core-reasoner"
    if any(k in text for k in ["search", "research"]):
        return "research-reasoner"
    return "chat-reasoner"