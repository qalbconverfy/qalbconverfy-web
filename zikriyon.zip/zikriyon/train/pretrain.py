from __future__ import annotations

import argparse
from pathlib import Path

import yaml

from .dataset_builder import DatasetConfig, create_datasets, load_text_corpus
from .checkpointing import CheckpointManager
from .trainer import Trainer, TrainConfig

from zikriyon.core.model import ModelConfig, ZikriyonModel
from zikriyon.tokenizer.tokenizer import ByteBPETokenizer, TokenizerConfig


def load_train_config(path: str = "configs/train.yaml") -> TrainConfig:
    """Load TrainConfig from YAML file"""
    cfg = TrainConfig()
    path = Path(path)
    
    if not path.exists():
        print(f"[Warning] {path} not found. Using default config.")
        return cfg

    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}

    # Update config from yaml
    for key, value in data.items():
        if hasattr(cfg, key):
            setattr(cfg, key, value)

    return cfg


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/train.yaml")
    parser.add_argument("--data-dir", default=None)
    parser.add_argument("--resume", default="")
    args = parser.parse_args()

    cfg = load_train_config(args.config)

    if args.data_dir:
        cfg.data_dir = args.data_dir
    if args.resume:
        cfg.resume = args.resume

    print(f"[Config] Loaded from {args.config}")
    print(f"[Config] max_steps={cfg.max_steps}, batch_size={cfg.batch_size}, block_size={cfg.block_size}")

    text = load_text_corpus(cfg.data_dir)
    if not text or len(text) < 500:
        print("[Warning] Using dummy data for testing")
        text = "The quick brown fox jumps over the lazy dog. " * 400

    tokenizer = ByteBPETokenizer(TokenizerConfig(vocab_size=32000))

    train_ds, val_ds = create_datasets(
        tokenizer, text, DatasetConfig(block_size=cfg.block_size, min_tokens=cfg.min_tokens)
    )

    model = ZikriyonModel(ModelConfig(
        vocab_size=32000,
        d_model=512,
        n_heads=8,
        n_layers=6,
        d_ff=2048
    ))

    ckpt_manager = CheckpointManager(cfg.ckpt_dir)
    trainer = Trainer(model, tokenizer, train_ds, val_ds, cfg, ckpt_manager)

    result = trainer.train()
    print(result)


if __name__ == "__main__":
    main()