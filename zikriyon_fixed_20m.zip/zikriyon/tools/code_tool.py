from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import subprocess


@dataclass
class CodeResult:
    stdout: str
    stderr: str
    returncode: int


class CodeTool:
    def run(self, command: list[str], cwd: str | None = None, timeout: int = 30) -> CodeResult:
        proc = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return CodeResult(stdout=proc.stdout, stderr=proc.stderr, returncode=proc.returncode)