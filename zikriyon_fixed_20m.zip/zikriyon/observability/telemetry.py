from __future__ import annotations

from dataclasses import dataclass, field

from .metrics import Metrics
from .tracing import Tracer


@dataclass
class Telemetry:
    metrics: Metrics = field(default_factory=Metrics)
    tracer: Tracer = field(default_factory=Tracer)

    def log_step(self, name: str, payload: dict) -> None:
        self.metrics.inc(name)
        self.tracer.record(name, payload)