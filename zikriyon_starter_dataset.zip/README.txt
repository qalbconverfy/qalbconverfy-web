Zikriyon Starter Dataset

Use:
1. Extract this ZIP.
2. Copy the data/raw folder into your zikriyon_fixed_20m project folder.
3. Train tokenizer:
   python -m zikriyon.train.train_tokenizer --input data\raw --output tokenizer --vocab-size 8000
4. Train model:
   python -m zikriyon.train.train --stage 0 --data-dir data\raw --batch-size 1 --block-size 128 --max-steps 5000

This is a small starter dataset for testing real file loading.
It is not enough for a powerful AI model.
Add more clean .txt files for better training.
