from __future__ import annotations

import gradio as gr

from zikriyon.inference.runner import InferenceRunner


def build_demo() -> gr.Blocks:
    runner = InferenceRunner.build_default()

    def respond(message: str, history: list[tuple[str, str]]):
        reply = runner.run(message)
        history = history + [(message, reply)]
        return "", history

    with gr.Blocks(title="Zikriyon") as demo:
        gr.Markdown("# Zikriyon")
        chatbot = gr.Chatbot(height=500)
        msg = gr.Textbox(label="Message", placeholder="Type a message...")
        state = gr.State([])

        msg.submit(respond, [msg, state], [msg, chatbot])
    return demo


def main() -> None:
    demo = build_demo()
    demo.launch(server_name="0.0.0.0", server_port=7860)