"""
zikriyon/model/seq2seq_model.py
--------------------------------
ZikriyonModel — the complete encoder-decoder Seq2Seq model.

Architecture flow:
    src_ids  → ZikriyonEncoder → enc_hidden_states
    tgt_ids  → ZikriyonDecoder (cross-attends to enc_hidden_states) → dec_hidden_states
    dec_hidden_states → LMHead → logits (batch, tgt_len, vocab_size)

Shapes
------
    src_ids  : (batch, src_len)
    tgt_ids  : (batch, tgt_len)
    logits   : (batch, tgt_len, vocab_size)
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any

from ..config   import ZikriyonConfig
from .encoder   import ZikriyonEncoder
from .decoder   import ZikriyonDecoder
from .lm_head   import LMHead


class ZikriyonModel(nn.Module):
    """
    Zikriyon — from-scratch encoder-decoder transformer.

    Initialization
    --------------
        cfg = ZikriyonConfig()
        model = ZikriyonModel(cfg)

    Forward pass
    ------------
        logits = model(src_ids, tgt_ids, src_mask=..., tgt_mask=...)
        # logits: (batch, tgt_len, vocab_size)

    Checkpoint
    ----------
        model.save("checkpoints/zikriyon_epoch1.pt")
        model = ZikriyonModel.load("checkpoints/zikriyon_epoch1.pt", cfg)
    """

    def __init__(self, cfg: ZikriyonConfig):
        super().__init__()
        self.cfg = cfg

        # ── Encoder ──────────────────────────────────────────────────────
        self.encoder = ZikriyonEncoder(
            vocab_size   = cfg.vocab_size,
            d_model      = cfg.d_model,
            n_heads      = cfg.n_heads,
            d_ff         = cfg.d_ff,
            n_layers     = cfg.n_enc_layers,
            max_src_len  = cfg.max_src_len,
            dropout      = cfg.dropout,
            pad_token_id = cfg.pad_token_id,
            pos_enc_type = cfg.pos_enc_type,
        )

        # ── Decoder ──────────────────────────────────────────────────────
        self.decoder = ZikriyonDecoder(
            vocab_size   = cfg.vocab_size,
            d_model      = cfg.d_model,
            n_heads      = cfg.n_heads,
            d_ff         = cfg.d_ff,
            n_layers     = cfg.n_dec_layers,
            max_tgt_len  = cfg.max_tgt_len,
            dropout      = cfg.dropout,
            pad_token_id = cfg.pad_token_id,
            pos_enc_type = cfg.pos_enc_type,
        )

        # ── Language model head ──────────────────────────────────────────
        self.lm_head = LMHead(
            d_model    = cfg.d_model,
            vocab_size = cfg.vocab_size,
        )

        # Tie encoder embedding weights to LM head (saves parameters)
        self.lm_head.tie_weights(self.encoder.embedding.token_embed.embed.weight)

        # Parameter count
        total = sum(p.numel() for p in self.parameters())
        print(f"[ZikriyonModel] Initialized — {total/1e6:.2f}M parameters")

    # ── Mask helpers ─────────────────────────────────────────────────────────

    def _make_src_mask(self, src_ids: torch.Tensor) -> torch.Tensor:
        """(batch, src_len) → (batch, 1, 1, src_len)"""
        return (src_ids != self.cfg.pad_token_id).unsqueeze(1).unsqueeze(2)

    def _make_tgt_mask(self, tgt_ids: torch.Tensor) -> torch.Tensor:
        """Padding mask for decoder input. (batch, 1, 1, tgt_len)"""
        return (tgt_ids != self.cfg.pad_token_id).unsqueeze(1).unsqueeze(2)

    # ── Encode ───────────────────────────────────────────────────────────────

    def encode(
        self,
        src_ids:  torch.Tensor,                    # (batch, src_len)
        src_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, src_len)
    ) -> torch.Tensor:
        """Run encoder only. Returns (batch, src_len, d_model)."""
        if src_mask is None:
            src_mask = self._make_src_mask(src_ids)
        return self.encoder(src_ids, src_mask)

    # ── Decode ───────────────────────────────────────────────────────────────

    def decode(
        self,
        tgt_ids:  torch.Tensor,                    # (batch, tgt_len)
        enc_out:  torch.Tensor,                    # (batch, src_len, d_model)
        tgt_mask: Optional[torch.Tensor] = None,
        enc_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Run decoder only. Returns (batch, tgt_len, d_model)."""
        if tgt_mask is None:
            tgt_mask = self._make_tgt_mask(tgt_ids)
        return self.decoder(tgt_ids, enc_out, tgt_mask=tgt_mask, enc_mask=enc_mask)

    # ── Full forward ──────────────────────────────────────────────────────────

    def forward(
        self,
        src_ids:  torch.Tensor,                    # (batch, src_len)
        tgt_ids:  torch.Tensor,                    # (batch, tgt_len)
        src_mask: Optional[torch.Tensor] = None,   # auto-built if None
        tgt_mask: Optional[torch.Tensor] = None,   # auto-built if None
    ) -> torch.Tensor:
        """
        Full encoder-decoder forward pass.

        Returns
        -------
        logits : (batch, tgt_len, vocab_size)
        """
        # Build masks from padding positions if not provided
        if src_mask is None:
            src_mask = self._make_src_mask(src_ids)
        if tgt_mask is None:
            tgt_mask = self._make_tgt_mask(tgt_ids)

        # Encoder: source → contextual hidden states
        enc_out = self.encoder(src_ids, src_mask)           # (batch, src_len, d_model)

        # Decoder: shifted targets + encoder memory → decoder hidden states
        dec_out = self.decoder(tgt_ids, enc_out,            # (batch, tgt_len, d_model)
                               tgt_mask=tgt_mask,
                               enc_mask=src_mask)

        # LM head: hidden states → vocabulary logits
        logits = self.lm_head(dec_out)                      # (batch, tgt_len, vocab_size)

        return logits

    # ── Parameter count ───────────────────────────────────────────────────────

    def num_parameters(self, trainable_only: bool = True) -> int:
        if trainable_only:
            return sum(p.numel() for p in self.parameters() if p.requires_grad)
        return sum(p.numel() for p in self.parameters())

    # ── Checkpoint save / load ────────────────────────────────────────────────

    def save(self, path: str) -> None:
        import json, pathlib
        pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "model_state_dict": self.state_dict(),
            "config": vars(self.cfg),
            "version": self.cfg.version,
        }, path)
        print(f"[ZikriyonModel] checkpoint saved → {path}")

    @classmethod
    def load(cls, path: str, cfg: Optional[ZikriyonConfig] = None) -> "ZikriyonModel":
        from ..config import ZikriyonConfig
        ckpt = torch.load(path, map_location="cpu")
        if cfg is None:
            cfg = ZikriyonConfig(**ckpt["config"])
        model = cls(cfg)
        model.load_state_dict(ckpt["model_state_dict"])
        print(f"[ZikriyonModel] checkpoint loaded ← {path}")
        return model

    def __repr__(self) -> str:
        return (
            f"ZikriyonModel(\n"
            f"  encoder_layers={self.cfg.n_enc_layers},\n"
            f"  decoder_layers={self.cfg.n_dec_layers},\n"
            f"  d_model={self.cfg.d_model},\n"
            f"  n_heads={self.cfg.n_heads},\n"
            f"  vocab_size={self.cfg.vocab_size},\n"
            f"  params={self.num_parameters()/1e6:.2f}M\n"
            f")"
        )
