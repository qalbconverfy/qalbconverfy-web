"""
zikriyon/data/dataset.py
-------------------------
Dataset pipeline for Zikriyon.

Supports:
  - seq2seq paired data  (source → target)
  - unpaired / language-modelling data (source only)
  - instruction-format data  ({"instruction": ..., "output": ...} JSON lines)

All data is tokenized and padded here. The DataLoader returns:
    src_ids       : (batch, src_len)   encoder input
    tgt_ids       : (batch, tgt_len)   decoder input  (shifted right = BOS + tokens)
    labels        : (batch, tgt_len)   decoder target (tokens + EOS, pad=-100)
    src_mask      : (batch, src_len)   1 = real token
"""

import json
import random
import re
from pathlib import Path
from typing import List, Optional, Dict, Tuple

import torch
from torch.utils.data import Dataset, DataLoader


# ── Text cleaning ─────────────────────────────────────────────────────────────

def clean_text(text: str) -> str:
    """Basic normalization: collapse whitespace, strip leading/trailing."""
    text = text.strip()
    text = re.sub(r"\r\n|\r", "\n", text)         # normalize line endings
    text = re.sub(r"[ \t]+", " ", text)            # collapse horizontal whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)         # max 2 blank lines
    return text


def deduplicate(samples: List[Dict]) -> List[Dict]:
    """Deduplicate by source text (exact match)."""
    seen = set()
    out = []
    for s in samples:
        key = s["src"].strip()
        if key not in seen:
            seen.add(key)
            out.append(s)
    return out


# ── Loaders ───────────────────────────────────────────────────────────────────

def load_paired_jsonl(path: str) -> List[Dict]:
    """
    Load paired seq2seq data from a .jsonl file.
    Each line: {"src": "...", "tgt": "..."}
    """
    samples = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            samples.append({"src": clean_text(obj["src"]), "tgt": clean_text(obj["tgt"])})
    return samples


def load_instruction_jsonl(path: str) -> List[Dict]:
    """
    Load instruction-tuning data from a .jsonl file.
    Each line: {"instruction": "...", "input": "...", "output": "..."}
    input field is optional.
    """
    samples = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            instruction = obj.get("instruction", "")
            inp = obj.get("input", "")
            src = f"{instruction} {inp}".strip() if inp else instruction
            tgt = obj.get("output", "")
            samples.append({"src": clean_text(src), "tgt": clean_text(tgt)})
    return samples


def load_text_file(path: str, max_seq_len: int = 512) -> List[Dict]:
    """
    Load a plain text file for language-modelling style (no target).
    Splits into chunks of up to max_seq_len characters for rough sizing.
    """
    samples = []
    with open(path, encoding="utf-8") as f:
        text = f.read()
    text = clean_text(text)
    # paragraph-level split
    paragraphs = [p.strip() for p in re.split(r"\n\n+", text) if p.strip()]
    for para in paragraphs:
        samples.append({"src": para, "tgt": para})   # autoregressive: src = tgt
    return samples


def split_samples(
    samples: List[Dict],
    train_frac: float = 0.9,
    val_frac: float = 0.05,
    seed: int = 42,
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    """Split into train / val / test."""
    random.seed(seed)
    random.shuffle(samples)
    n = len(samples)
    n_train = int(n * train_frac)
    n_val   = int(n * val_frac)
    train = samples[:n_train]
    val   = samples[n_train : n_train + n_val]
    test  = samples[n_train + n_val :]
    return train, val, test


# ── PyTorch Dataset ───────────────────────────────────────────────────────────

class ZikriyonDataset(Dataset):
    """
    Token-level seq2seq dataset.

    Each item returned:
        src_ids  : LongTensor (src_len,)
        tgt_ids  : LongTensor (tgt_len,)  — BOS + tokens (decoder input)
        labels   : LongTensor (tgt_len,)  — tokens + EOS, pad=-100 (loss target)
        src_mask : LongTensor (src_len,)  — 1 for real tokens
    """

    def __init__(
        self,
        samples: List[Dict],
        tokenizer,
        max_src_len: int = 512,
        max_tgt_len: int = 512,
    ):
        self.tokenizer   = tokenizer
        self.max_src_len = max_src_len
        self.max_tgt_len = max_tgt_len
        self.samples     = samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        sample = self.samples[idx]

        # ── Encode source (encoder input): BOS + tokens + EOS
        src_ids_list = self.tokenizer.encode(
            sample["src"],
            add_bos=True,
            add_eos=True,
            max_length=self.max_src_len,
        )

        # ── Encode target
        # tgt_tokens: just the raw token ids without BOS/EOS
        tgt_tokens = self.tokenizer.encode(
            sample["tgt"],
            add_bos=False,
            add_eos=False,
            max_length=self.max_tgt_len - 1,    # leave room for BOS/EOS
        )

        # decoder input  = BOS + tgt_tokens  (teacher forcing)
        tgt_ids_list = [self.tokenizer.bos_token_id] + tgt_tokens

        # labels         = tgt_tokens + EOS  (what we predict)
        labels_list  = tgt_tokens + [self.tokenizer.eos_token_id]

        # Pad to max_tgt_len
        pad_len = self.max_tgt_len - len(tgt_ids_list)
        tgt_ids_list = tgt_ids_list + [self.tokenizer.pad_token_id] * pad_len
        labels_list  = labels_list  + [-100] * pad_len          # -100 = ignore in loss

        # Pad source
        src_len = len(src_ids_list)
        src_pad = self.max_src_len - src_len
        src_mask_list = [1] * src_len + [0] * src_pad
        src_ids_list  = src_ids_list + [self.tokenizer.pad_token_id] * src_pad

        return {
            "src_ids":  torch.tensor(src_ids_list, dtype=torch.long),
            "tgt_ids":  torch.tensor(tgt_ids_list, dtype=torch.long),
            "labels":   torch.tensor(labels_list,  dtype=torch.long),
            "src_mask": torch.tensor(src_mask_list, dtype=torch.long),
        }


# ── DataLoader factory ────────────────────────────────────────────────────────

def build_dataloaders(
    train_samples: List[Dict],
    val_samples:   List[Dict],
    tokenizer,
    max_src_len: int = 512,
    max_tgt_len: int = 512,
    batch_size:  int = 32,
    num_workers: int = 0,
) -> Tuple[DataLoader, DataLoader]:

    train_ds = ZikriyonDataset(train_samples, tokenizer, max_src_len, max_tgt_len)
    val_ds   = ZikriyonDataset(val_samples,   tokenizer, max_src_len, max_tgt_len)

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
    )
    return train_loader, val_loader