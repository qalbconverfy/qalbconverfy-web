from .model import ZikriyonModel, ModelConfig

__all__ = ["ZikriyonModel", "ModelConfig"]