from __future__ import annotations

import torch
from torch import nn

from .layers import DecoderBlock, RMSNorm


class Decoder(nn.Module):
    def __init__(
        self,
        n_layers: int,
        d_model: int,
        n_heads: int,
        d_ff: int,
        dropout: float = 0.0,
        max_seq_len: int = 4096,
        rope_theta: float = 10000.0,
    ) -> None:
        super().__init__()
        self.blocks = nn.ModuleList(
            [
                DecoderBlock(d_model, n_heads, d_ff, dropout, max_seq_len, rope_theta)
                for _ in range(n_layers)
            ]
        )
        self.norm = RMSNorm(d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for block in self.blocks:
            x = block(x)
        return self.norm(x)