from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple
import torch


@dataclass
class BatchCollator:
    pad_token_id: int = 0

    def collate(self, samples: List[Tuple[torch.Tensor, torch.Tensor]]) -> Tuple[torch.Tensor, torch.Tensor]:
        xs, ys = zip(*samples)
        x = torch.stack(xs)
        y = torch.stack(ys)
        return x, y