from zikriyon.safety.gates import SafetyGate
from zikriyon.safety.policy import SafetyPolicy

def test_safety_blocks_destructive():
    gate = SafetyGate(SafetyPolicy())
    result = gate.check("delete all files", "file")
    assert result.allowed is False