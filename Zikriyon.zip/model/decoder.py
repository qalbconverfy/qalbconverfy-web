"""
zikriyon/model/decoder.py
--------------------------
Decoder stack for Zikriyon.

Architecture per layer (pre-norm style):
    x → Norm → Causal Self-Attention    → residual
      → Norm → Cross-Attention          → residual
      → Norm → FeedForward              → residual

Full decoder:
    tgt_ids → Embedding → N × DecoderLayer → final Norm → hidden states

Shapes
------
    tgt_ids   : (batch, tgt_len)
    enc_out   : (batch, src_len, d_model)
    tgt_mask  : (batch, 1, tgt_len, tgt_len)   combined causal + pad mask
    enc_mask  : (batch, 1, 1,      src_len)    encoder padding mask
    output    : (batch, tgt_len, d_model)
"""

import torch
import torch.nn as nn
from typing import Optional

from .embeddings      import ZikriyonEmbedding
from .attention       import MultiHeadSelfAttention
from .cross_attention import MultiHeadCrossAttention
from .encoder         import FeedForward
from .norms           import LayerNorm


# ── Single decoder layer ──────────────────────────────────────────────────────

class DecoderLayer(nn.Module):
    """
    One Transformer decoder layer (pre-norm).

    Sub-layers:
        1. Causal self-attention        (masked, decoder sees only past tokens)
        2. Cross-attention              (decoder attends to full encoder memory)
        3. Feed-forward

    Each: output = input + SubLayer(LayerNorm(input))
    """

    def __init__(self, d_model: int, n_heads: int, d_ff: int, dropout: float = 0.1):
        super().__init__()

        self.norm1 = LayerNorm(d_model)
        self.norm2 = LayerNorm(d_model)
        self.norm3 = LayerNorm(d_model)

        # Sub-layer 1: causal self-attention (causal=True enforces look-ahead mask)
        self.self_attn = MultiHeadSelfAttention(
            d_model=d_model,
            n_heads=n_heads,
            dropout=dropout,
            causal=True,
        )

        # Sub-layer 2: cross-attention over encoder hidden states
        self.cross_attn = MultiHeadCrossAttention(
            d_model=d_model,
            n_heads=n_heads,
            dropout=dropout,
        )

        # Sub-layer 3: feed-forward
        self.ff = FeedForward(d_model, d_ff, dropout)

    def forward(
        self,
        x:        torch.Tensor,                    # (batch, tgt_len, d_model)
        enc_out:  torch.Tensor,                    # (batch, src_len, d_model)
        tgt_mask: Optional[torch.Tensor] = None,   # (batch, 1, tgt_len, tgt_len) — padding
        enc_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, src_len)
    ) -> torch.Tensor:

        # 1. Causal self-attention
        residual = x
        x = self.norm1(x)
        x = self.self_attn(x, attn_mask=tgt_mask)
        x = residual + x

        # 2. Cross-attention to encoder
        residual = x
        x = self.norm2(x)
        x = self.cross_attn(x, enc_out, enc_mask=enc_mask)
        x = residual + x

        # 3. Feed-forward
        residual = x
        x = self.norm3(x)
        x = self.ff(x)
        x = residual + x

        return x    # (batch, tgt_len, d_model)


# ── Full decoder ──────────────────────────────────────────────────────────────

class ZikriyonDecoder(nn.Module):
    """
    Full Zikriyon decoder stack.

    Pipeline:
        tgt_ids → Embedding
                → N × DecoderLayer(causal self-attn + cross-attn + FF)
                → LayerNorm
                → dec_hidden_states  (fed to LM head for logits)

    Parameters
    ----------
    vocab_size   : tokenizer vocabulary size
    d_model      : hidden size
    n_heads      : attention heads
    d_ff         : feed-forward inner size
    n_layers     : number of decoder blocks
    max_tgt_len  : max target sequence length
    dropout      : dropout rate
    pad_token_id : padding token id
    pos_enc_type : "sinusoidal" | "learned" | "rotary"
    """

    def __init__(
        self,
        vocab_size:   int,
        d_model:      int,
        n_heads:      int,
        d_ff:         int,
        n_layers:     int,
        max_tgt_len:  int   = 512,
        dropout:      float = 0.1,
        pad_token_id: int   = 0,
        pos_enc_type: str   = "sinusoidal",
    ):
        super().__init__()

        self.embedding = ZikriyonEmbedding(
            vocab_size   = vocab_size,
            d_model      = d_model,
            max_len      = max_tgt_len,
            dropout      = dropout,
            pad_token_id = pad_token_id,
            pos_enc_type = pos_enc_type,
        )

        self.layers = nn.ModuleList([
            DecoderLayer(d_model, n_heads, d_ff, dropout)
            for _ in range(n_layers)
        ])

        self.final_norm = LayerNorm(d_model)

    @staticmethod
    def make_tgt_pad_mask(tgt_ids: torch.Tensor, pad_token_id: int) -> torch.Tensor:
        """
        Padding mask for decoder input.
        1 = real token, 0 = pad.
        Shape: (batch, 1, 1, tgt_len) — broadcast-compatible with self-attention.

        Note: causal masking is handled inside MultiHeadSelfAttention (causal=True),
        so we only need the padding mask here.
        """
        return (tgt_ids != pad_token_id).unsqueeze(1).unsqueeze(2)

    def forward(
        self,
        tgt_ids:  torch.Tensor,                    # (batch, tgt_len)
        enc_out:  torch.Tensor,                    # (batch, src_len, d_model)
        tgt_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, tgt_len) padding
        enc_mask: Optional[torch.Tensor] = None,   # (batch, 1, 1, src_len)
    ) -> torch.Tensor:

        # (batch, tgt_len) → (batch, tgt_len, d_model)
        x = self.embedding(tgt_ids)

        # Pass through N decoder layers
        for layer in self.layers:
            x = layer(x, enc_out, tgt_mask=tgt_mask, enc_mask=enc_mask)

        # Final layer norm
        x = self.final_norm(x)

        return x    # (batch, tgt_len, d_model) — decoder hidden states
