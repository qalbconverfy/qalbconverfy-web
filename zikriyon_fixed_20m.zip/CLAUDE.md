# Zikriyon

Zikriyon is a production-grade, AGI-style local assistant with planning, memory, tool use, safety gates, self-evaluation, and supervised online learning.

## Project Goals
- Build a local-first assistant that can chat, plan, browse, code, create PDFs, and manage files.
- Keep the system modular, testable, observable, and launchable on a laptop or small VPS.
- Keep image generation disabled until explicitly added later.
- Prioritize reliability, safety, auditability, and rollback.

## Core Architecture
- `tokenizer/`: tokenization and tokenizer training.
- `core/`: model internals such as embeddings, attention, decoder, FFN, and generation.
- `planner/`: task decomposition and goal management.
- `router/`: tool and model routing.
- `memory/`: short-term memory, long-term memory, approved memory, retrieval.
- `judge/`: response scoring, verification, safety scoring.
- `safety/`: policy gates, permissions, sandboxing, validation, audit.
- `tools/`: browser, code, PDF, file, command, search, fetch, registry.
- `agents/`: higher-level composed agent workflows.
- `train/`: tokenizer training, pretraining, fine-tuning, online learning, checkpoints.
- `eval/`: smoke tests, regression tests, tool evaluation, memory evaluation, safety evaluation.
- `inference/`: chat loop, API, streaming, formatting.
- `ui/`: local demo UI.
- `orchestration/`: workflow lifecycle and state machine.
- `observability/`: logging, metrics, tracing, telemetry.

## Development Rules
- Prefer small, composable modules.
- Keep public interfaces stable once introduced.
- Add tests for each new file or behavior.
- Avoid hidden global state.
- Keep code Python 3.10+ compatible.
- Keep runtime paths configurable from `configs/`.

## Safety Rules
- Do not hardcode secrets.
- Do not log environment variables.
- Do not read or write secrets into memory.
- Do not learn from unverified web content without verification and provenance tracking.
- Do not run destructive shell commands without explicit approval.
- Do not self-modify code automatically.
- Do not enable image generation in the initial release.

## Tool Rules
- Use browser/search only when fresh or verified information is required.
- Use code tools for debugging, patching, and running tests.
- Use PDF tools only when a document export is requested.
- Use file tools only for explicit file operations.
- Use command tools only when necessary and with the safest possible arguments.
- Prefer dry-run or preview behavior when available.

## Memory Rules
- Store only approved or verified information.
- Keep provenance for each memory write.
- Separate session memory from long-term memory.
- Keep a quarantine path for untrusted web-derived content.

## Training Rules
- Start with tokenizer and model scaffolding.
- Then implement tools, planner, router, memory, judge, and safety.
- Use staged checkpoints.
- Only use approved feedback for online learning.
- Save rollback checkpoints for every major stage.

## Evaluation Rules
- Run smoke tests before integration tests.
- Validate tool success and failure handling.
- Validate memory retrieval and provenance behavior.
- Validate safety gates before launch.
- Keep regression tests for critical paths.

## Done Criteria
A feature is complete only when:
- code exists,
- tests pass,
- config is added,
- and the behavior is documented in README or comments where needed.


zikriyon/
├── CLAUDE.md
├── README.md
├── pyproject.toml
├── requirements.txt
├── LICENSE
├── .gitignore
├── .env.example
├── configs/
│   ├── base.yaml
│   ├── model.yaml
│   ├── train.yaml
│   ├── eval.yaml
│   ├── safety.yaml
│   └── tools.yaml
├── tokenizer/
│   ├── __init__.py
│   ├── tokenizer.py
│   ├── train_tokenizer.py
│   ├── vocab.json
│   ├── merges.txt
│   └── special_tokens.json
├── core/
│   ├── __init__.py
│   ├── model.py
│   ├── decoder.py
│   ├── encoder.py
│   ├── attention.py
│   ├── ffn.py
│   ├── embeddings.py
│   ├── rope.py
│   ├── layers.py
│   ├── generation.py
│   └── losses.py
├── planner/
│   ├── __init__.py
│   ├── planner.py
│   ├── task_parser.py
│   ├── step_builder.py
│   └── goal_manager.py
├── router/
│   ├── __init__.py
│   ├── router.py
│   ├── tool_selector.py
│   ├── model_router.py
│   └── policy_router.py
├── memory/
│   ├── __init__.py
│   ├── memory.py
│   ├── short_term.py
│   ├── long_term.py
│   ├── approved_memory.py
│   ├── memory_store.py
│   ├── retrieval.py
│   └── provenance.py
├── judge/
│   ├── __init__.py
│   ├── judge.py
│   ├── scorer.py
│   ├── verifier.py
│   ├── critic.py
│   └── safety_score.py
├── safety/
│   ├── __init__.py
│   ├── policy.py
│   ├── gates.py
│   ├── permissions.py
│   ├── sandbox.py
│   ├── validators.py
│   └── audit.py
├── tools/
│   ├── __init__.py
│   ├── browser_tool.py
│   ├── code_tool.py
│   ├── pdf_tool.py
│   ├── file_tool.py
│   ├── command_tool.py
│   ├── search_tool.py
│   ├── fetch_tool.py
│   └── tool_registry.py
├── agents/
│   ├── __init__.py
│   ├── base_agent.py
│   ├── chat_agent.py
│   ├── research_agent.py
│   ├── coding_agent.py
│   ├── pdf_agent.py
│   ├── memory_agent.py
│   └── supervisor_agent.py
├── train/
│   ├── __init__.py
│   ├── train.py
│   ├── train_tokenizer.py
│   ├── pretrain.py
│   ├── finetune.py
│   ├── online_train.py
│   ├── dataset_builder.py
│   ├── collator.py
│   └── checkpointing.py
├── eval/
│   ├── __init__.py
│   ├── eval.py
│   ├── smoke_test.py
│   ├── regression_test.py
│   ├── tool_eval.py
│   ├── safety_eval.py
│   ├── memory_eval.py
│   └── benchmark.py
├── inference/
│   ├── __init__.py
│   ├── chat.py
│   ├── api.py
│   ├── runner.py
│   ├── stream.py
│   └── formatter.py
├── ui/
│   ├── __init__.py
│   ├── app.py
│   ├── components.py
│   ├── state.py
│   └── styles.css
├── orchestration/
│   ├── __init__.py
│   ├── workflow.py
│   ├── state_machine.py
│   └── lifecycle.py
├── observability/
│   ├── __init__.py
│   ├── logger.py
│   ├── metrics.py
│   ├── tracing.py
│   └── telemetry.py
├── data/
│   ├── raw/
│   ├── processed/
│   ├── approved/
│   ├── memory/
│   └── fixtures/
├── checkpoints/
│   ├── stage0/
│   ├── stage1/
│   ├── stage2/
│   └── best/
├── logs/
│   ├── audit.jsonl
│   ├── app.log
│   └── eval.log
├── prompts/
│   ├── system.txt
│   ├── planner.txt
│   ├── router.txt
│   ├── judge.txt
│   └── tool_prompts/
├── scripts/
│   ├── setup_env.sh
│   ├── run_local.sh
│   ├── launch_ui.sh
│   └── export_pdf.sh
└── tests/
    ├── __init__.py
    ├── test_tokenizer.py
    ├── test_model.py
    ├── test_planner.py
    ├── test_router.py
    ├── test_memory.py
    ├── test_judge.py
    ├── test_safety.py
    ├── test_tools.py
    ├── test_train.py
    ├── test_eval.py
    ├── test_inference.py
    └── test_ui.py