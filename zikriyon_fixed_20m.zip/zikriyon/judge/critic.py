from __future__ import annotations


def critique_response(text: str) -> str:
    if len(text.strip()) < 20:
        return "Response is too short."
    if not text.endswith((".", "!", "?")):
        return "Response should end with punctuation."
    return "Response looks acceptable."