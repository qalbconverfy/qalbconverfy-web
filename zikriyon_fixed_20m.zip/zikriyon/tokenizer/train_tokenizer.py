from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable

from .tokenizer import ByteBPETokenizer, TokenizerConfig


def read_corpus(paths: Iterable[str]) -> list[str]:
    texts: list[str] = []
    for item in paths:
        path = Path(item)
        if path.is_dir():
            for file in sorted(path.rglob("*.txt")):
                texts.append(file.read_text(encoding="utf-8", errors="ignore"))
        elif path.is_file():
            texts.append(path.read_text(encoding="utf-8", errors="ignore"))
    return texts


def main() -> None:
    parser = argparse.ArgumentParser(description="Train Zikriyon tokenizer")
    parser.add_argument("--input", nargs="+", required=True, help="Text files or directories")
    parser.add_argument("--output", required=True, help="Output tokenizer directory")
    parser.add_argument("--vocab-size", type=int, default=32000)
    args = parser.parse_args()

    texts = read_corpus(args.input)
    tokenizer = ByteBPETokenizer(TokenizerConfig(vocab_size=args.vocab_size))
    tokenizer.train(texts, target_vocab_size=args.vocab_size)
    tokenizer.save(args.output)
    print(f"Tokenizer saved to {args.output}")


if __name__ == "__main__":
    main()