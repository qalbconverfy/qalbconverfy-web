# Zikriyon

**A fully original, from-scratch encoder-decoder transformer — built entirely in Python and PyTorch.**

No pretrained weights. No third-party model code. No external APIs.
Every layer, every parameter, every training loop is yours.

---

## Architecture

```
Source Text / Code
      │
      ▼
 ZikriyonTokenizer  (BPE, trained on your corpus)
      │
      ▼
 ZikriyonEncoder
   ├── TokenEmbedding  +  SinusoidalPositionalEncoding
   └── N × EncoderLayer
         ├── Pre-Norm
         ├── MultiHeadSelfAttention  (bidirectional)
         ├── Residual
         ├── Pre-Norm
         └── FeedForward (GELU)  +  Residual
      │
      ▼
 Encoder Hidden States  (batch, src_len, d_model)
      │
      ├─────────────────────────────────────┐
      │                                     │
      ▼                                     │ cross-attention
 ZikriyonDecoder                            │
   ├── TokenEmbedding  +  PositionalEnc    │
   └── N × DecoderLayer                    │
         ├── Pre-Norm                       │
         ├── Causal Self-Attention          │
         ├── Residual                       │
         ├── Pre-Norm                       │
         ├── CrossAttention ───────────────┘
         ├── Residual
         ├── Pre-Norm
         └── FeedForward  +  Residual
      │
      ▼
 Decoder Hidden States  (batch, tgt_len, d_model)
      │
      ▼
 LMHead  →  Vocabulary Logits  (batch, tgt_len, vocab_size)
      │
      ▼
 Next-Token Prediction / Sampling
```

---

## Project Structure

```
zikriyon/
├── config/
│   └── config.py          ← ZikriyonConfig dataclass + tiny/small/base presets
├── tokenizer/
│   ├── tokenizer.py       ← From-scratch BPE tokenizer
│   └── train_tokenizer.py ← CLI to train on your corpus
├── data/
│   └── dataset.py         ← Dataset, DataLoader, loaders for paired/instruction/text data
├── model/
│   ├── embeddings.py      ← Token embedding + sinusoidal/learned/RoPE positional encoding
│   ├── norms.py           ← LayerNorm + RMSNorm
│   ├── attention.py       ← Multi-Head Self-Attention (bidirectional + causal)
│   ├── cross_attention.py ← Multi-Head Cross-Attention (decoder → encoder)
│   ├── encoder.py         ← EncoderLayer + ZikriyonEncoder
│   ├── decoder.py         ← DecoderLayer + ZikriyonDecoder
│   ├── lm_head.py         ← Language model head (d_model → vocab_size)
│   └── seq2seq_model.py   ← ZikriyonModel (full encoder-decoder)
├── train/
│   ├── trainer.py         ← Training loop, loss, checkpointing
│   ├── scheduler.py       ← Warmup + cosine LR scheduler
│   └── train.py           ← Entry-point CLI
├── eval/
│   └── evaluate.py        ← Loss, perplexity, BLEU, token accuracy, sanity checks
├── inference/
│   ├── generator.py       ← Autoregressive generator (greedy, top-k, top-p)
│   └── run.py             ← CLI for interactive / batch inference
├── utils/
│   └── utils.py           ← Seeds, device, logging, checkpoint helpers
├── checkpoints/           ← Saved model checkpoints
├── logs/                  ← Training logs
└── setup.py
```

---

## Quick Start

### 1. Install

```bash
pip install torch numpy
pip install -e zikriyon/   # editable install
```

### 2. Train the tokenizer

```bash
python -m zikriyon.tokenizer.train_tokenizer \
    --corpus data/raw/corpus.txt \
    --vocab_size 8000 \
    --output tokenizer/zikriyon_tokenizer.json
```

### 3. Prepare data

Your data file should be a `.jsonl` file with one JSON object per line:

```jsonl
{"src": "Translate to French: Hello, world!", "tgt": "Bonjour le monde!"}
{"src": "Summarize: The transformer...", "tgt": "Transformer is an attention-based model."}
```

For instruction-tuning format:
```jsonl
{"instruction": "Write a Python function", "input": "that reverses a string", "output": "def reverse(s): return s[::-1]"}
```

### 4. Overfit sanity test (no data needed)

```bash
python -m zikriyon.train.train --mode overfit
```

This runs 30 epochs on 16 tiny dummy samples. Loss should drop to near 0.

### 5. Real training

```bash
python -m zikriyon.train.train \
    --mode train \
    --config small \
    --data_path data/paired.jsonl \
    --tokenizer_path tokenizer/zikriyon_tokenizer.json \
    --epochs 20 \
    --batch_size 16
```

Resume from a checkpoint:
```bash
python -m zikriyon.train.train \
    --mode train \
    --config small \
    --data_path data/paired.jsonl \
    --tokenizer_path tokenizer/zikriyon_tokenizer.json \
    --resume checkpoints/zikriyon_epoch010.pt
```

### 6. Evaluate

```bash
python -m zikriyon.eval.evaluate \
    --checkpoint checkpoints/zikriyon_best.pt \
    --tokenizer  tokenizer/zikriyon_tokenizer.json \
    --data_path  data/val.jsonl
```

### 7. Inference

```bash
# Single prompt
python -m zikriyon.inference.run \
    --checkpoint checkpoints/zikriyon_best.pt \
    --tokenizer  tokenizer/zikriyon_tokenizer.json \
    --prompt "Summarize: Transformers use self-attention to model sequences."

# Interactive mode
python -m zikriyon.inference.run \
    --checkpoint checkpoints/zikriyon_best.pt \
    --tokenizer  tokenizer/zikriyon_tokenizer.json \
    --interactive
```

---

## Configuration Presets

| Preset | d_model | Layers | Heads | d_ff  | Context | Params (approx) |
|--------|---------|--------|-------|-------|---------|-----------------|
| tiny   | 128     | 2+2    | 4     | 512   | 64      | ~2M             |
| small  | 256     | 4+4    | 4     | 1024  | 256     | ~12M            |
| base   | 512     | 6+6    | 8     | 2048  | 512     | ~65M            |

Use `tiny` for local testing on CPU. Use `small` on a single GPU. Use `base` for serious training.

---

## Python API

```python
from zikriyon import ZikriyonConfig, ZikriyonModel, ZikriyonTokenizer, ZikriyonGenerator

# Load config
cfg = ZikriyonConfig(vocab_size=8000, d_model=256, n_heads=4)

# Build model
model = ZikriyonModel(cfg)
print(model)

# Forward pass (shapes)
import torch
src = torch.randint(0, 8000, (2, 64))   # (batch=2, src_len=64)
tgt = torch.randint(0, 8000, (2, 32))   # (batch=2, tgt_len=32)
logits = model(src, tgt)
print(logits.shape)                       # (2, 32, 8000)

# Save / Load
model.save("checkpoints/my_checkpoint.pt")
model2 = ZikriyonModel.load("checkpoints/my_checkpoint.pt", cfg)

# Generate
tok = ZikriyonTokenizer.load("tokenizer/zikriyon_tokenizer.json")
gen = ZikriyonGenerator(model, tok, cfg, device="cpu")
output = gen.generate("What is machine learning?", temperature=0.8, top_k=40)
print(output)
```

---

## Roadmap (Zikriyon v0.x → v1.0)

| Phase | Goal |
|-------|------|
| v0.1  | Base encoder-decoder, BPE tokenizer, full training pipeline ✅ |
| v0.2  | Rotary position encoding (RoPE), RMSNorm option |
| v0.3  | Instruction-tuning pipeline |
| v0.4  | Retrieval-augmented generation (RAG) |
| v0.5  | Code assistant specialization |
| v0.6  | Multi-GPU training (DDP) |
| v0.7  | Larger context window (2k–8k) |
| v0.8  | Preference tuning (DPO / RLHF) |
| v1.0  | Full LLM scaling (1B+ parameters) |

---

## Design Principles

- **Fully original** — no copied model weights, no pretrained checkpoints, no third-party LLMs
- **Modular** — each component is a separate file, easy to swap or extend
- **Scalable** — designed to grow from ~12M → 1B+ parameters without a rewrite
- **Readable** — tensor shapes documented in every module, clear code over clever tricks
- **Config-driven** — all hyperparameters in one `ZikriyonConfig` dataclass

---

*Zikriyon is built to be yours — every layer, every weight, every line of code.*
