"""
zikriyon/model/lm_head.py
--------------------------
Language Model Head for Zikriyon.

Maps decoder hidden states → vocabulary logits for next-token prediction.

Shapes
------
    hidden_states : (batch, tgt_len, d_model)
    logits        : (batch, tgt_len, vocab_size)

Optional weight tying:
    Share weights between token embedding and the LM head projection.
    This reduces parameter count and often improves performance.
"""

import torch
import torch.nn as nn
from typing import Optional


class LMHead(nn.Module):
    """
    Language Model Head.

    A single linear layer: d_model → vocab_size
    (no activation — raw logits for cross-entropy loss or sampling)

    Weight tying: if `embedding_weight` is provided, the projection matrix
    is tied to the token embedding weight, saving vocab_size × d_model parameters.
    """

    def __init__(
        self,
        d_model:    int,
        vocab_size: int,
        bias:       bool = False,
    ):
        super().__init__()
        self.proj = nn.Linear(d_model, vocab_size, bias=bias)
        nn.init.normal_(self.proj.weight, std=0.02)

    def tie_weights(self, embedding_weight: nn.Parameter) -> None:
        """
        Tie the projection weight to the token embedding weight.
        Must be called AFTER both modules are created.

        embedding_weight : the `.weight` of a TokenEmbedding or nn.Embedding
        """
        assert self.proj.weight.shape == embedding_weight.shape, (
            f"Shape mismatch: LM head {self.proj.weight.shape} vs "
            f"embedding {embedding_weight.shape}"
        )
        self.proj.weight = embedding_weight

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        hidden_states : (batch, tgt_len, d_model)

        Returns
        -------
        logits : (batch, tgt_len, vocab_size)
            Raw unnormalized scores over the vocabulary.
        """
        return self.proj(hidden_states)
