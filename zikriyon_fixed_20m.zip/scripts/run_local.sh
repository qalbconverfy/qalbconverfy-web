#!/usr/bin/env bash
set -euo pipefail

source .venv/bin/activate
python -m zikriyon.inference.chat "${1:-Hello Zikriyon}"