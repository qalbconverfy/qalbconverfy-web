from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass
class GoalManager:
    active_goals: List[str] = field(default_factory=list)

    def add_goal(self, goal: str) -> None:
        if goal not in self.active_goals:
            self.active_goals.append(goal)

    def remove_goal(self, goal: str) -> None:
        self.active_goals = [g for g in self.active_goals if g != goal]

    def list_goals(self) -> List[str]:
        return list(self.active_goals)