import torch
from zikriyon.core.model import ZikriyonModel, ModelConfig

def test_model_forward():
    model = ZikriyonModel(ModelConfig(vocab_size=100, d_model=32, n_heads=4, n_layers=2, d_ff=64))
    x = torch.randint(0, 100, (2, 8))
    y = model(x)
    assert y.shape == (2, 8, 100)