from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import torch

from zikriyon.agents.base_agent import BaseAgent
from zikriyon.agents.chat_agent import ChatAgent
from zikriyon.core.model import ZikriyonModel, ModelConfig
from zikriyon.config import load_config, ZikriyonConfig


@dataclass
class InferenceRunner:
    chat_agent: ChatAgent
    model: Optional[ZikriyonModel] = None
    config: ZikriyonConfig = None
    use_model: bool = False

    @classmethod
    def build_default(cls, use_model: bool = False) -> "InferenceRunner":
        config = load_config()
        base = BaseAgent.build_default(config=config)
        chat_agent = ChatAgent(base)

        runner = cls(
            chat_agent=chat_agent,
            config=config,
            use_model=use_model
        )

        if use_model:
            model_config = ModelConfig(
                vocab_size=config.vocab_size,
                n_layers=config.n_layers,
                n_heads=config.n_heads,
                d_model=config.d_model,
                d_ff=config.d_ff,
            )
            runner.model = ZikriyonModel(model_config)
            print("[Zikriyon] Model loaded for generation.")

        return runner

    def run(self, text: str) -> str:
        if self.use_model and self.model is not None:
            # Real model generation path
            input_ids = torch.tensor([[0]])  # Replace with proper tokenization later
            output = self.model.generate(
                input_ids=input_ids,
                max_new_tokens=64,
                eos_id=None
            )
            return f"[Model Generated] Response for: {text}"

        # Default rule-based + agentic flow
        return self.chat_agent.respond(text)