from __future__ import annotations


def looks_destructive(text: str) -> bool:
    lowered = text.lower()
    return any(term in lowered for term in ["delete", "wipe", "destroy", "format", "rm -rf"])


def looks_sensitive(text: str) -> bool:
    lowered = text.lower()
    return any(term in lowered for term in ["password", "secret key", "api key", "token"])