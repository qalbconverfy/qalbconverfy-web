from .pretrain import main as pretrain_main
from .train_tokenizer import main as train_tokenizer_main

__all__ = ["pretrain_main", "train_tokenizer_main"]