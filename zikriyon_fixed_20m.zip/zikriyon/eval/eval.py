from __future__ import annotations

import argparse

from .benchmark import benchmark
from .memory_eval import memory_eval
from .regression_test import regression_test
from .safety_eval import safety_eval
from .smoke_test import smoke_test
from .tool_eval import tool_eval


def main() -> None:
    parser = argparse.ArgumentParser(description="Zikriyon evaluation entrypoint")
    parser.add_argument("--suite", choices=["smoke", "regression", "tool", "safety", "memory", "benchmark"], default="smoke")
    args = parser.parse_args()

    mapping = {
        "smoke": smoke_test,
        "regression": regression_test,
        "tool": tool_eval,
        "safety": safety_eval,
        "memory": memory_eval,
        "benchmark": benchmark,
    }
    result = mapping[args.suite]()
    print(result)


if __name__ == "__main__":
    main()