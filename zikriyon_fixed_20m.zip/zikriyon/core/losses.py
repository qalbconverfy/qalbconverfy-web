from __future__ import annotations

import torch
import torch.nn.functional as F


def causal_lm_loss(logits: torch.Tensor, labels: torch.Tensor, ignore_index: int = -100) -> torch.Tensor:
    vocab = logits.size(-1)
    return F.cross_entropy(logits.view(-1, vocab), labels.view(-1), ignore_index=ignore_index)