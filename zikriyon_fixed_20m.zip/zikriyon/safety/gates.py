from __future__ import annotations

from dataclasses import dataclass

from .permissions import PermissionResult
from .policy import SafetyPolicy
from .validators import looks_destructive, looks_sensitive


@dataclass
class SafetyGate:
    policy: SafetyPolicy

    def check(self, task: str, tool: str) -> PermissionResult:
        text = task.lower()
        if tool not in self.policy.allowed_tools:
            return PermissionResult(False, f"Tool '{tool}' not allowed")
        if looks_sensitive(text):
            return PermissionResult(False, "Sensitive data handling blocked")
        if looks_destructive(text) and not self.policy.allow_destructive:
            return PermissionResult(False, "Destructive action requires explicit approval")
        if "command" in text and not self.policy.allow_command:
            return PermissionResult(False, "Shell command execution disabled by policy")
        return PermissionResult(True, "Allowed by safety policy")