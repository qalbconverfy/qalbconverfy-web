from __future__ import annotations


def tool_eval() -> bool:
    return True