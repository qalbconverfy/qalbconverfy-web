from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from zikriyon.judge.judge import Judge
from zikriyon.memory.memory import MemoryManager
from zikriyon.planner.planner import Planner
from zikriyon.router.router import Router
from zikriyon.safety.audit import AuditLogger
from zikriyon.safety.gates import SafetyGate
from zikriyon.safety.policy import SafetyPolicy
from zikriyon.tools.tool_registry import ToolRegistry
from zikriyon.config import ZikriyonConfig, load_config


@dataclass
class BaseAgent:
    planner: Planner
    router: Router
    memory: MemoryManager
    judge: Judge
    safety_gate: SafetyGate
    tools: ToolRegistry
    audit: AuditLogger
    config: Optional[ZikriyonConfig] = None

    @classmethod
    def build_default(cls, config: Optional[ZikriyonConfig] = None) -> "BaseAgent":
        if config is None:
            config = load_config()

        policy = SafetyPolicy.from_config(config)

        return cls(
            planner=Planner(),
            router=Router(),
            memory=MemoryManager(),
            judge=Judge(),
            safety_gate=SafetyGate(policy),
            tools=ToolRegistry(),
            audit=AuditLogger(),
            config=config,
        )