from zikriyon.planner.planner import Planner

def test_planner_creates_steps():
    plan = Planner().plan("research the topic and write a pdf")
    assert len(plan.steps) >= 1