from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class FileResult:
    path: str
    content: str


class FileTool:
    def read(self, path: str) -> FileResult:
        p = Path(path)
        return FileResult(path=str(p), content=p.read_text(encoding="utf-8", errors="ignore"))

    def write(self, path: str, content: str) -> FileResult:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return FileResult(path=str(p), content=content)