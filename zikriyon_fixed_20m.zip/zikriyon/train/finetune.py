from __future__ import annotations

from .pretrain import main as pretrain_main


def main():
    print("Finetune stage is not fully implemented yet.")
    print("Running pretrain as base for now...")
    pretrain_main()


if __name__ == "__main__":
    main()