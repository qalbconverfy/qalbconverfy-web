"""
zikriyon/train/trainer.py
--------------------------
Training loop for Zikriyon.

Features
--------
- Teacher-forced seq2seq training
- Label-smoothed cross-entropy loss
- Warmup + cosine / constant LR scheduler
- Gradient clipping
- Checkpoint save/resume (best model + epoch-based)
- Train and validation loss logging
- Perplexity reporting

Usage
-----
    from zikriyon.train.trainer import ZikriyonTrainer
    trainer = ZikriyonTrainer(model, cfg, train_loader, val_loader)
    trainer.train()
"""

import math
import os
import time
import logging
from pathlib import Path
from typing import Optional

import torch
import torch.nn as nn
from torch.optim import AdamW
from torch.utils.data import DataLoader

from ..config        import ZikriyonConfig
from ..model         import ZikriyonModel
from .scheduler      import WarmupCosineScheduler

logger = logging.getLogger("zikriyon.train")


# ── Loss ─────────────────────────────────────────────────────────────────────

class LabelSmoothedCrossEntropy(nn.Module):
    """
    Cross-entropy loss with optional label smoothing.

    Smoothing distributes `epsilon` of the probability mass uniformly
    across all classes, reducing overconfidence.

    Ignores positions where label == -100 (padding).
    """

    def __init__(self, vocab_size: int, smoothing: float = 0.1, ignore_index: int = -100):
        super().__init__()
        self.vocab_size   = vocab_size
        self.smoothing    = smoothing
        self.ignore_index = ignore_index

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        """
        logits : (batch, seq_len, vocab_size)
        labels : (batch, seq_len)   -100 = ignore
        """
        batch, seq_len, vocab = logits.shape

        logits = logits.reshape(-1, vocab)                 # (batch*seq_len, vocab)
        labels = labels.reshape(-1)                        # (batch*seq_len,)

        # Mask padded positions
        mask = labels != self.ignore_index
        logits = logits[mask]
        labels = labels[mask]

        if logits.numel() == 0:
            return torch.tensor(0.0, device=logits.device, requires_grad=True)

        log_probs = torch.log_softmax(logits, dim=-1)      # (n_real, vocab)

        if self.smoothing == 0.0:
            loss = -log_probs.gather(1, labels.unsqueeze(1)).squeeze(1)
        else:
            # Label-smoothed NLL
            nll_loss = -log_probs.gather(1, labels.unsqueeze(1)).squeeze(1)
            smooth_loss = -log_probs.mean(dim=-1)
            loss = (1 - self.smoothing) * nll_loss + self.smoothing * smooth_loss

        return loss.mean()


# ── Trainer ───────────────────────────────────────────────────────────────────

class ZikriyonTrainer:
    """
    Full training loop for ZikriyonModel.

    Parameters
    ----------
    model        : ZikriyonModel instance
    cfg          : ZikriyonConfig
    train_loader : DataLoader for training data
    val_loader   : DataLoader for validation data (optional)
    resume_from  : path to checkpoint to resume from (optional)
    """

    def __init__(
        self,
        model:        ZikriyonModel,
        cfg:          ZikriyonConfig,
        train_loader: DataLoader,
        val_loader:   Optional[DataLoader] = None,
        resume_from:  Optional[str] = None,
    ):
        self.model        = model
        self.cfg          = cfg
        self.train_loader = train_loader
        self.val_loader   = val_loader
        self.device       = torch.device(cfg.device if torch.cuda.is_available() else "cpu")

        # Move model to device
        self.model.to(self.device)

        # Loss
        self.criterion = LabelSmoothedCrossEntropy(
            vocab_size=cfg.vocab_size,
            smoothing=cfg.label_smoothing,
        )

        # Optimizer
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=cfg.learning_rate,
            weight_decay=cfg.weight_decay,
            betas=(0.9, 0.98),
            eps=1e-9,
        )

        # Scheduler
        total_steps = cfg.max_epochs * len(train_loader)
        self.scheduler = WarmupCosineScheduler(
            self.optimizer,
            warmup_steps=cfg.warmup_steps,
            total_steps=total_steps,
        )

        # Checkpoint tracking
        self.ckpt_dir  = Path(cfg.checkpoint_dir)
        self.ckpt_dir.mkdir(parents=True, exist_ok=True)
        self.best_val_loss = float("inf")
        self.start_epoch   = 0
        self.global_step   = 0

        # Resume
        if resume_from:
            self._load_checkpoint(resume_from)

        # Logging setup
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s  %(name)s  %(levelname)s  %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(Path(cfg.log_dir) / "train.log"),
            ],
        )
        Path(cfg.log_dir).mkdir(parents=True, exist_ok=True)

    # ── Training step ────────────────────────────────────────────────────────

    def _train_step(self, batch: dict) -> float:
        """Forward + backward + optimizer step. Returns loss value."""
        src_ids  = batch["src_ids"].to(self.device)   # (batch, src_len)
        tgt_ids  = batch["tgt_ids"].to(self.device)   # (batch, tgt_len)
        labels   = batch["labels"].to(self.device)    # (batch, tgt_len)

        # Forward pass
        logits = self.model(src_ids, tgt_ids)          # (batch, tgt_len, vocab)

        # Loss
        loss = self.criterion(logits, labels)

        # Backward
        self.optimizer.zero_grad()
        loss.backward()

        # Gradient clipping
        nn.utils.clip_grad_norm_(self.model.parameters(), self.cfg.grad_clip)

        self.optimizer.step()
        self.scheduler.step()

        return loss.item()

    # ── Validation ───────────────────────────────────────────────────────────

    @torch.no_grad()
    def _validate(self) -> float:
        if self.val_loader is None:
            return float("nan")

        self.model.eval()
        total_loss, n_batches = 0.0, 0

        for batch in self.val_loader:
            src_ids = batch["src_ids"].to(self.device)
            tgt_ids = batch["tgt_ids"].to(self.device)
            labels  = batch["labels"].to(self.device)

            logits = self.model(src_ids, tgt_ids)
            loss   = self.criterion(logits, labels)
            total_loss += loss.item()
            n_batches  += 1

        self.model.train()
        return total_loss / max(n_batches, 1)

    # ── Checkpoint helpers ────────────────────────────────────────────────────

    def _save_checkpoint(self, epoch: int, val_loss: float, is_best: bool = False) -> None:
        state = {
            "epoch":             epoch,
            "global_step":       self.global_step,
            "model_state_dict":  self.model.state_dict(),
            "optimizer_state":   self.optimizer.state_dict(),
            "scheduler_state":   self.scheduler.state_dict(),
            "best_val_loss":     self.best_val_loss,
            "config":            vars(self.cfg),
        }
        path = self.ckpt_dir / f"zikriyon_epoch{epoch:03d}.pt"
        torch.save(state, path)
        logger.info(f"Checkpoint saved → {path}")

        if is_best:
            best_path = self.ckpt_dir / "zikriyon_best.pt"
            torch.save(state, best_path)
            logger.info(f"Best checkpoint updated → {best_path}")

    def _load_checkpoint(self, path: str) -> None:
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt["model_state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer_state"])
        self.scheduler.load_state_dict(ckpt["scheduler_state"])
        self.best_val_loss = ckpt.get("best_val_loss", float("inf"))
        self.start_epoch   = ckpt.get("epoch", 0) + 1
        self.global_step   = ckpt.get("global_step", 0)
        logger.info(f"Resumed from {path} (epoch {self.start_epoch})")

    # ── Main training loop ────────────────────────────────────────────────────

    def train(self) -> None:
        logger.info(
            f"Starting training: {self.cfg.max_epochs} epochs | "
            f"device={self.device} | "
            f"params={self.model.num_parameters()/1e6:.2f}M"
        )
        self.model.train()

        for epoch in range(self.start_epoch, self.cfg.max_epochs):
            epoch_loss = 0.0
            n_batches  = 0
            t0         = time.time()

            for step, batch in enumerate(self.train_loader):
                loss = self._train_step(batch)
                epoch_loss += loss
                n_batches  += 1
                self.global_step += 1

                if self.global_step % self.cfg.log_every_n_steps == 0:
                    lr = self.scheduler.get_last_lr()[0]
                    logger.info(
                        f"epoch={epoch+1:3d}  step={self.global_step:6d}  "
                        f"loss={loss:.4f}  lr={lr:.2e}"
                    )

            avg_train_loss = epoch_loss / max(n_batches, 1)
            val_loss       = self._validate()
            ppl            = math.exp(min(val_loss, 20)) if not math.isnan(val_loss) else float("nan")
            elapsed        = time.time() - t0

            logger.info(
                f"── Epoch {epoch+1:3d} ──  "
                f"train_loss={avg_train_loss:.4f}  "
                f"val_loss={val_loss:.4f}  "
                f"val_ppl={ppl:.2f}  "
                f"time={elapsed:.1f}s"
            )

            # Save checkpoint
            if (epoch + 1) % self.cfg.save_every_n_epochs == 0:
                is_best = val_loss < self.best_val_loss
                if is_best:
                    self.best_val_loss = val_loss
                self._save_checkpoint(epoch + 1, val_loss, is_best=is_best)

        logger.info("Training complete.")
