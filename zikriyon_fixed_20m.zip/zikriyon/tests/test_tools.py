from zikriyon.tools.file_tool import FileTool

def test_file_tool_write_read(tmp_path):
    tool = FileTool()
    p = tmp_path / "a.txt"
    tool.write(str(p), "hello")
    assert tool.read(str(p)).content == "hello"