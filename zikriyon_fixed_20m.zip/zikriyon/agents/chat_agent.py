from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from zikriyon.core.model import ZikriyonModel
from .base_agent import BaseAgent


@dataclass
class ChatAgent:
    base: BaseAgent
    model: Optional[ZikriyonModel] = None

    def respond(self, user_text: str) -> str:
        plan = self.base.planner.plan(user_text)
        route = self.base.router.route(user_text)
        gate = self.base.safety_gate.check(user_text, route.tool)

        if not gate.allowed:
            return f"Blocked by safety policy: {gate.reason}"

        self.base.memory.remember_turn(user_text)

        if self.model is not None:
            return f"[Model Active] Planned response for: {user_text}"

        summary = f"Planned {len(plan.steps)} step(s) with tool '{route.tool}'."
        judge = self.base.judge.evaluate(summary)
        return summary