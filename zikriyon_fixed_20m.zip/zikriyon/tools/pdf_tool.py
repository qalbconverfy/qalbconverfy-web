from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas


@dataclass
class PdfResult:
    path: str


class PdfTool:
    def write_text_pdf(self, path: str, title: str, body: str) -> PdfResult:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        c = canvas.Canvas(str(target), pagesize=A4)
        width, height = A4
        c.setFont("Helvetica-Bold", 16)
        c.drawString(40, height - 50, title)
        c.setFont("Helvetica", 11)
        y = height - 80
        for line in body.splitlines():
            c.drawString(40, y, line[:110])
            y -= 16
            if y < 50:
                c.showPage()
                y = height - 50
        c.save()
        return PdfResult(path=str(target))