from __future__ import annotations

from fastapi import FastAPI
from pydantic import BaseModel

from .runner import InferenceRunner

app = FastAPI(title="Zikriyon API", version="0.1.0")
runner = InferenceRunner.build_default()


class ChatRequest(BaseModel):
    text: str


class ChatResponse(BaseModel):
    response: str


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    return ChatResponse(response=runner.run(req.text))