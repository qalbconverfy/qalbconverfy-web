from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TraceEvent:
    name: str
    payload: dict[str, Any]


@dataclass
class Tracer:
    events: list[TraceEvent] = field(default_factory=list)

    def record(self, name: str, payload: dict[str, Any]) -> None:
        self.events.append(TraceEvent(name=name, payload=payload))