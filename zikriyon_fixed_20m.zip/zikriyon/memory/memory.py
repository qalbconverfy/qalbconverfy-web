from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from .long_term import LongTermMemory
from .memory_store import JsonMemoryStore
from .provenance import Provenance
from .short_term import ShortTermMemory


@dataclass
class MemoryItem:
    key: str
    value: Any
    provenance: Provenance
    confidence: float = 1.0


@dataclass
class MemoryManager:
    short_term_max_items: int = 32
    storage_path: str = "logs/memory.json"
    approved_only_writes: bool = True
    short_term: ShortTermMemory = field(init=False)
    long_term: LongTermMemory = field(init=False)
    store: JsonMemoryStore = field(init=False)

    def __post_init__(self) -> None:
        self.short_term = ShortTermMemory(max_items=self.short_term_max_items)
        self.long_term = LongTermMemory()
        self.store = JsonMemoryStore(self.storage_path)

    def remember_turn(self, text: str) -> None:
        self.short_term.add(text)

    def write(self, key: str, value: Any, provenance: Provenance, approved: bool = False, confidence: float = 1.0) -> bool:
        if self.approved_only_writes and not approved:
            return False
        item = MemoryItem(key=key, value=value, provenance=provenance, confidence=confidence)
        self.long_term.set(key, item)
        self.store.append(
            {
                "key": key,
                "value": value,
                "provenance": provenance.__dict__,
                "confidence": confidence,
            }
        )
        return True

    def read(self, key: str, default: Any = None) -> Any:
        item = self.long_term.get(key)
        if item is None:
            return default
        return item.value if hasattr(item, "value") else item

    def snapshot(self) -> Dict[str, Any]:
        return {
            "short_term": self.short_term.list(),
            "long_term_keys": self.long_term.keys(),
        }