"""
zikriyon/eval/evaluate.py
--------------------------
Evaluation script for Zikriyon.

Metrics tracked:
    - Validation loss
    - Perplexity
    - BLEU score (sentence-level, no external deps)
    - Token accuracy
    - Overfit sanity check
    - Cross-attention sanity check (encoder output non-zero)
    - Generation quality (qualitative sample outputs)

Usage
-----
    python -m zikriyon.eval.evaluate \
        --checkpoint checkpoints/zikriyon_best.pt \
        --tokenizer  tokenizer/zikriyon_tokenizer.json \
        --data_path  data/val.jsonl
"""

import argparse
import math
import logging
from collections import Counter
from typing import List, Tuple

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from ..config     import ZikriyonConfig
from ..model      import ZikriyonModel
from ..tokenizer  import ZikriyonTokenizer
from ..data       import load_paired_jsonl, ZikriyonDataset
from ..train      import LabelSmoothedCrossEntropy
from ..inference  import ZikriyonGenerator

logger = logging.getLogger("zikriyon.eval")
logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")


# ── BLEU helpers (from scratch, no external deps) ─────────────────────────────

def _ngrams(tokens: List[str], n: int) -> Counter:
    return Counter(tuple(tokens[i:i+n]) for i in range(len(tokens) - n + 1))


def sentence_bleu(hypothesis: List[str], reference: List[str], max_n: int = 4) -> float:
    """Simple sentence-level BLEU without smoothing (for rough quality gauge)."""
    if not hypothesis:
        return 0.0

    bp = min(1.0, math.exp(1 - len(reference) / max(1, len(hypothesis))))
    precisions = []
    for n in range(1, max_n + 1):
        hyp_ngrams = _ngrams(hypothesis, n)
        ref_ngrams = _ngrams(reference,  n)
        if not hyp_ngrams:
            precisions.append(0.0)
            continue
        clipped = sum(min(c, ref_ngrams[g]) for g, c in hyp_ngrams.items())
        precisions.append(clipped / max(1, sum(hyp_ngrams.values())))

    if any(p == 0 for p in precisions):
        return 0.0

    log_avg = sum(math.log(p) for p in precisions) / max_n
    return bp * math.exp(log_avg)


def corpus_bleu(hypotheses: List[str], references: List[str]) -> float:
    """Average sentence BLEU over a corpus."""
    scores = [
        sentence_bleu(h.split(), r.split())
        for h, r in zip(hypotheses, references)
    ]
    return sum(scores) / max(1, len(scores))


# ── Core evaluator ────────────────────────────────────────────────────────────

class ZikriyonEvaluator:

    def __init__(
        self,
        model:     ZikriyonModel,
        tokenizer: ZikriyonTokenizer,
        cfg:       ZikriyonConfig,
        device:    str = "cpu",
    ):
        self.model     = model
        self.tokenizer = tokenizer
        self.cfg       = cfg
        self.device    = torch.device(device)
        self.model.to(self.device)
        self.model.eval()

        self.criterion = LabelSmoothedCrossEntropy(
            vocab_size=cfg.vocab_size,
            smoothing=0.0,           # use raw CE for eval
        )
        self.generator = ZikriyonGenerator(model, tokenizer, cfg, device=device)

    # ── Loss + perplexity ────────────────────────────────────────────────────

    @torch.no_grad()
    def compute_loss_and_ppl(self, loader: DataLoader) -> Tuple[float, float]:
        total_loss, n_batches = 0.0, 0
        for batch in loader:
            src_ids = batch["src_ids"].to(self.device)
            tgt_ids = batch["tgt_ids"].to(self.device)
            labels  = batch["labels"].to(self.device)

            logits = self.model(src_ids, tgt_ids)
            loss   = self.criterion(logits, labels)
            total_loss += loss.item()
            n_batches  += 1

        avg_loss = total_loss / max(n_batches, 1)
        ppl      = math.exp(min(avg_loss, 20))
        return avg_loss, ppl

    # ── Token accuracy ───────────────────────────────────────────────────────

    @torch.no_grad()
    def compute_token_accuracy(self, loader: DataLoader) -> float:
        correct, total = 0, 0
        for batch in loader:
            src_ids = batch["src_ids"].to(self.device)
            tgt_ids = batch["tgt_ids"].to(self.device)
            labels  = batch["labels"].to(self.device)

            logits   = self.model(src_ids, tgt_ids)          # (B, T, V)
            preds    = logits.argmax(dim=-1)                  # (B, T)
            mask     = labels != -100
            correct += (preds[mask] == labels[mask]).sum().item()
            total   += mask.sum().item()

        return correct / max(total, 1)

    # ── Generation quality ───────────────────────────────────────────────────

    def generate_samples(self, samples: list, n: int = 5) -> List[dict]:
        results = []
        for s in samples[:n]:
            pred = self.generator.generate(s["src"])
            results.append({"src": s["src"], "target": s["tgt"], "predicted": pred})
        return results

    # ── Cross-attention sanity check ─────────────────────────────────────────

    @torch.no_grad()
    def cross_attention_sanity(self, sample: dict) -> bool:
        """
        Check that encoder output is non-zero and decoder cross-attention is working.
        Returns True if sanity passes.
        """
        src_ids = torch.tensor(
            [self.tokenizer.encode(sample["src"], add_bos=True, add_eos=True,
                                   max_length=self.cfg.max_src_len)],
            dtype=torch.long, device=self.device
        )
        tgt_ids = torch.tensor(
            [self.tokenizer.encode(sample["tgt"], add_bos=True, add_eos=False,
                                   max_length=self.cfg.max_tgt_len)],
            dtype=torch.long, device=self.device
        )

        src_mask = self.model._make_src_mask(src_ids)
        enc_out  = self.model.encoder(src_ids, src_mask)
        enc_norm = enc_out.norm().item()

        tgt_mask = self.model._make_tgt_mask(tgt_ids)
        dec_out  = self.model.decoder(tgt_ids, enc_out,
                                       tgt_mask=tgt_mask, enc_mask=src_mask)
        dec_norm = dec_out.norm().item()

        pass_enc = enc_norm > 0.01
        pass_dec = dec_norm > 0.01
        logger.info(f"Cross-attn sanity: enc_norm={enc_norm:.4f}  dec_norm={dec_norm:.4f}  "
                    f"pass={pass_enc and pass_dec}")
        return pass_enc and pass_dec

    # ── Full evaluation report ────────────────────────────────────────────────

    def run(self, loader: DataLoader, samples: list, n_samples: int = 5) -> dict:
        logger.info("Running evaluation...")

        loss, ppl  = self.compute_loss_and_ppl(loader)
        acc        = self.compute_token_accuracy(loader)
        gen_out    = self.generate_samples(samples, n=n_samples)
        bleu       = corpus_bleu(
            [g["predicted"] for g in gen_out],
            [g["target"]    for g in gen_out],
        )
        sanity     = self.cross_attention_sanity(samples[0]) if samples else False

        report = {
            "val_loss":       round(loss, 4),
            "perplexity":     round(ppl,  2),
            "token_accuracy": round(acc,  4),
            "bleu":           round(bleu * 100, 2),
            "cross_attn_ok":  sanity,
        }

        logger.info("── Evaluation Results ──────────────────────────")
        for k, v in report.items():
            logger.info(f"  {k:<20} {v}")

        logger.info("── Generation Samples ──────────────────────────")
        for i, g in enumerate(gen_out):
            logger.info(f"  [{i+1}] src      : {g['src'][:80]}")
            logger.info(f"       target   : {g['target'][:80]}")
            logger.info(f"       predicted: {g['predicted'][:80]}")

        return report


# ── CLI ───────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Evaluate Zikriyon")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--tokenizer",  required=True)
    parser.add_argument("--data_path",  required=True)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--n_samples",  type=int, default=5)
    parser.add_argument("--device",     default="cpu")
    args = parser.parse_args()

    tokenizer = ZikriyonTokenizer.load(args.tokenizer)
    model     = ZikriyonModel.load(args.checkpoint)
    cfg       = model.cfg
    cfg.device = args.device

    samples = load_paired_jsonl(args.data_path)
    dataset = ZikriyonDataset(samples, tokenizer, cfg.max_src_len, cfg.max_tgt_len)
    loader  = DataLoader(dataset, batch_size=args.batch_size, shuffle=False)

    evaluator = ZikriyonEvaluator(model, tokenizer, cfg, device=args.device)
    evaluator.run(loader, samples, n_samples=args.n_samples)


if __name__ == "__main__":
    main()