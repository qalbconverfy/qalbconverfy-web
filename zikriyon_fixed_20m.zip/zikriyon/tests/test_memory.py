from zikriyon.memory.memory import MemoryManager
from zikriyon.memory.provenance import Provenance

def test_memory_write_read():
    mm = MemoryManager(approved_only_writes=False)
    ok = mm.write("k", "v", Provenance.new("test", "unit"), approved=True)
    assert ok is True
    assert mm.read("k") is not None