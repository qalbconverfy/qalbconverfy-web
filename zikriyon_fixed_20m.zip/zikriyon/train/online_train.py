from __future__ import annotations

from .pretrain import main as pretrain_main


def main():
    print("Online training is not implemented yet.")
    print("Running pretrain as base...")
    pretrain_main()


if __name__ == "__main__":
    main()